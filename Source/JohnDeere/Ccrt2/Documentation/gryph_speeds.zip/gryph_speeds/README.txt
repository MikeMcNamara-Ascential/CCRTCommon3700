
Gryph_speeds is a program that allows the default bit rates in a
Gryphon for CAN, J1850, KWP2000 and LIN cards to be modified.

Documentation for gryph_speeds is in gryph_speeds.html. 
gryph_speeds.exe is the MS Windows executable version of
gryph_speeds.pl.  Gryph_speeds is written in Perl/Tk (gryph_speeds.pl)
which can be executed on a PC if Perl and the Perl Tk module are
installed on it.

Gryphon.pm is the Gryphon Perl module.  Gryph_speeds uses it to
communicate with a Gryphon.  If gryph_speeds.pl is executed, Gryphon.pm
needs to be in the same directory or be installed in one of the
directories present in Perl's @INC array.  Documentation for Gryphon.pm
is in Gryphon.html.  This module is incorporated into gryph_speeds.exe
and is not needed on Windows system unless gryph_speeds.pl is executed.


To install gryph_speeds.exe on a Windows system, copy the files to a
directory.  The corresponding html files should be placed somewhere on
the hard drive too.  If desired, one or more shortcuts may be made for
gryph_speeds.exe.  Read the documentation file (gryph_speeds.html) with
a browser and run the program.



gryph_speeds.exe    Gryph_speeds utility program for Windows

Gryphon.pm          Gryphon Perl module
gryph_speeds.pl     Gryph_speeds utility program executable via Perl

gryph_speeds.html   Documentation for gryph_speeds
Gryphon.html        Documentation for the Gryphon Perl module


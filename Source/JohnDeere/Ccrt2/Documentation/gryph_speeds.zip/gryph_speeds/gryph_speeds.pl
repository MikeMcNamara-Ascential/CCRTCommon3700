#!/usr/bin/perl -w

# $Id: gryph_speeds.pl,v 1.1 2007/02/23 15:15:58 chang Exp $

use Tk;
use Tk::HList;
use Tk::BrowseEntry;
use Tk::LabFrame;
use Tk::Dialog;
use strict;
use Net::FTP;
use Net::Telnet qw(TELOPT_NAWS TELNET_IAC TELNET_SB TELNET_SE);

# The following lines are needed for the IndigoSTAR compiler

#use Tk::Menu;
#use Tk::Menubutton;
#use Tk::Checkbutton;
#use Tk::Radiobutton;
#use Tk::DialogBox;
#use Tk::Optionmenu;
#use Tk::Scale;
#use bytes;

# End of added lines

use Data::Dumper;

BEGIN {
    sub _WINDOWS_ () {1};
    require 'gmsg.ph';
    require 'gdev.ph';
}
use Gryphon;

# Tunable parameters:
my $configFilename = '.speedsrc';
my ($ip_address, $username, $password) = ('', qw/root dggryphon/);
my $EMPTY_ENTRY = '     ';
my @ALLOWED = (&GCAN, &GKWP2000, &GLIN, &GSCI, &GVISTNBUS);
my $tempLocation = '/tmp/speed';

# End of tunable parameters

my ($onlineInd, $online, $status, @changeAddr, $geometry, $modified, $changed);
my ($buttonPanel, @channelButtons, @speedButtons, @currentIndex, @ioctlData);
my ($configMenu, $addrWin);
my ($gryphon, $telnet);
my ($menu, @gdevs, $gdevsName, $editing, @startupIndex, %presets, @gdevIndex);
my (@speedData);
my $delete_menu;

my $MainWin = new MainWindow (-title => 'Gryphon Default Speeds - offline', -background, '#BBF');
$MainWin->optionAdd ('*background' => '#BBF');
$MainWin->optionAdd ('*foreground' => '#007');
$MainWin->optionAdd ('*Listbox.background' => '#DDF');
$MainWin->optionAdd ('*highlightBackground' => '#BBF');
$MainWin->optionAdd ('*activeBackground' => '#AAF');
$MainWin->optionAdd ('*troughColor' => '#99D');
$MainWin->optionAdd ('*selectBackground' => '#66A');
$MainWin->optionAdd ('*selectForeground' => '#FFF');

my $menubar = $MainWin->Menu(-type => 'menubar');
$MainWin->configure(-menu => $menubar);

$_ = $menubar->cascade( -label => 'File', -tearoff => 0);
$onlineInd = $_->checkbutton( -label => 'Connect', -selectcolor => '#AAF',
        -variable => \$online, -state => 'disabled', -command => sub {
	        $onlineInd->configure(-selectcolor => 'yellow');
	        register ($MainWin); });
$configMenu = $_->command(-label => 'Configuration...', -command => \&getAddress);
$_->separator;
my $saveMenu = $_->command( -label => 'Save File', -command => \&saveDataFile,
        -state => 'disabled' );
$_->separator;
$_->command( -label => 'Exit', -command => \&quit );


$_ = $menubar->cascade( -label => 'Help', -tearoff => 0);

$_->command( -label => 'About...', -command => \&about );

$_ = $MainWin->Frame()->pack(-side => 'top', -pady => 7, -fill => 'x');
my $menuButton = $_->Menubutton (-textvariable => \$gdevsName, -relief => 'raised',
    	-indicatoron => 1, -tearoff => 0)->
	pack (-side => 'left', -expand => 1);

my $list = $MainWin->Scrolled ('HList', -scrollbars => 'osoe', -header => 1,
    	-columns => 3, -itemtype => 'text', -height => 3)->pack (-side => 'top',
        -fill => 'both', -padx => 4, -pady => 4, -expand => 1);

$list->configure (-browsecmd => [\&moveEntry, $list]);
$list->configure (-command => [\&editEntry, $list]);

{
    my $col = 0;
    foreach (qw /Index Value(s) Description/) {
        $list->header ('create', $col++, -text => $_);
    }
}

sub about {
    my @months = qw/January February March April May June July August
   	    	    September October November December/;
    my ($version, $date) = 
    	    '$Id: gryph_speeds.pl,v 1.1 2007/02/23 15:15:58 chang Exp $' =~ 
	    /v\s+(\S+)\s+(\S+)/;
    my ($year, $month, $day) = split '/', $date ;
    $day =~ s/^0//;
    $MainWin->messageBox(-icon => 'info', -title => 'About download.pl',
    	    -message => "Version $version\n$months[$month-1] $day, $year",
	    -type => 'OK' );
}

$_ = $MainWin->Frame (-borderwidth => 2, -relief => 'raised')->
        pack (-side => 'top', -fill => 'x', -padx => 5, -pady => 7);
$buttonPanel = $_->Frame ()->
        pack (-side => 'top', -fill => 'x', -padx => 3, -pady => 5);

$MainWin->Label
	(-borderwidth => 2, -relief => 'sunken', -padx => 6,
	-pady => 3, -textvariable => \$status, -justify => 'left',
	-anchor => 'w')->
	pack (-side => 'bottom', -fill => 'x', -padx => 3, -pady => 2);

if (open INPUT, $configFilename) {
    eval <INPUT>;
    close INPUT;
}
$ip_address = '192.168.1.1' unless $ip_address;
$onlineInd->configure(-state => 'normal');
$onlineInd->configure(-label => "Connect to $ip_address");
$MainWin->minsize (400, 460);
$gdevsName = $EMPTY_ENTRY;

$MainWin->OnDestroy (\&quit);


MainLoop;

sub saveConfiguration {
    my $filename = shift;

    unless (open OUTPUT, ">$filename") {
    	$status = "Unable to open $filename: $!";
	return;
    }

    $Data::Dumper::Purity = 1;
    $Data::Dumper::Indent = 0;
    print OUTPUT Data::Dumper->Dump (
            [$ip_address, $username, $password],
            [qw/$ip_address $username $password /]);
    close OUTPUT;
}

{
my ($win, $exitInProgress);
sub register {
    my ($widget) = @_;
    my (@entry, $comment, $name, @speeds, $type, $subType);
    my ($lineNumber, $speedStart, $speedEnd);
    my ($result, $reply, $channel, @chanState, $index, %exists);
    my (@contents, %allowed, $state, $chan);
    my (@presets, @currentBTRs, $gdevEntry);

    if ($online) {
	$status = 'Establishing connection...';

	$gryphon = new Gryphon addr => $ip_address;
	unless ($gryphon) {
	    $status = $@;
	    $online = 0;
	    return;
	}

        $addrWin->destroy if $addrWin;
        $configMenu->configure (-state => 'disabled');
        $configMenu->configure (-foreground => 'darkgrey');
        $telnet = new Net::Telnet (timeout => 150, errmode => 'return',
                prompt => '/.+#\s+/') or goto bail;
        $telnet->open ($ip_address) or goto bail;
        $telnet->login ($username, $password) or goto bail;

	$onlineInd->configure (-selectcolor => 'green');
        $onlineInd->configure(-label => "Disconnect from $ip_address");

        foreach (@changeAddr) {
            $_->configure (-state => 'disabled');
        }

	$_ = $widget->cget (-title);
	s/\S+$/$ip_address  Online/;
	$widget->title ($_);
        $status = "Connected to $ip_address";
	$widget->update;

	($result, $reply) = $gryphon->cmdSend (cmd => &CMD_GET_CONFIG,
	    	gcDest => &SD_SERVER);
	unless ($result) {
            my ($setSpeedIoctl, $getSpeedIoctl, $dataSize, @data);

	    $reply = substr $reply, 64;     # Skip the device info
            $chan = 1;
            $buttonPanel->Label (-text => "Initial\nSpeed\nIndex")->
                    grid (-column => 0, -row => 2);
            $buttonPanel->Label (-text => "Current\nSpeed\nIndex")->
                    grid (-column => 0, -row => 3);
            #
            # The following statement appears to do nothing.  When running
            # under Linux, it does prevent the main window from resizing
            # itself.  It has no effect under Windoze.
            #
            $MainWin->geometry ($MainWin->geometry);
	    while ($reply) {
                my $ignore = 1; 
	    	($type, $subType) = (unpack 'a20a8a16Nn2a20C2', $reply)[7,8];
		push @{$exists{"$type:$subType"}}, $chan;
		$reply = substr $reply, 80;
                push @channelButtons, $buttonPanel->Optionmenu (
		    	-command => sub {
			$changed = 1;
			$saveMenu->configure (-state => 'normal');});
                push @speedButtons, $buttonPanel->Optionmenu (
		    	-command => [sub {
                        my $channel = shift;
                        if ($ignore) {
                            $ignore = undef;
                            return;
                        }
                        changeSpeed ($gdevs[$gdevIndex[$channel]], $channel,
                                $currentIndex[$channel], $ioctlData[$channel]);
			}, $chan]);
                $chan++;
	    }
           while (--$chan) {
                ($result, $reply) = $gryphon->cmdSend (gcDest => &SD_CARD,
                        gcDestChan => $chan, cmd => &CMD_CARD_GET_SPEEDS);
                next if $result;
                ($setSpeedIoctl, $getSpeedIoctl, $dataSize) =
                        unpack 'N2c', $reply;
                $reply = substr $reply, 10;
                $ioctlData[$chan]{size} = $dataSize;
                $ioctlData[$chan]{setspeed} = $setSpeedIoctl;
                $ioctlData[$chan]{getspeed} = $getSpeedIoctl;
                ($result, $reply) = $gryphon->cmdSend (gcDest => &SD_CARD,
                        gcDestChan => $chan, cmd => &CMD_CARD_IOCTL,
                        data => [$getSpeedIoctl, '0' x $dataSize],
                        dataRecipe => "Nc$dataSize");
                unless ($result) {
                    @currentBTRs = unpack "NC$dataSize", $reply;
                   @currentBTRs = map{$_ = sprintf '0x%02X', $_} @currentBTRs;
                   $ioctlData[$chan]{currentspeed} = join ' ', @currentBTRs;
                }
            }
   	}

	@contents = $telnet->cmd ('cat /gryphon/etc/gdevs') or goto bail;
    	@gdevs = ();
        $type = undef;
	while ($_ = shift @contents) {
	    if (/^\./) {
	    	push @gdevs, {data => [@entry],
		    	      name => $name,
			      speeds => [@speeds],
			      type => $type,
			      subtype => $subType,
			      speedstart => $speedStart,
			      speedend => $speedEnd,
			      present =>
                              ($type and exists $exists{"$type:$subType"}) ?
                                    $exists{"$type:$subType"} : undef};
		@entry= ();
		$entry[0] = $_;
		$name = $comment = $type = $speedStart = $speedEnd = undef;
		$lineNumber = 0;
		@speeds = ();
		if (/^.DEVICE\s+/) {
		    ($type, $subType) = /^\S+\s+(\S+)\s+(\S+)/;
                    $type = hex $type;
                    $subType = hex $subType;
		}
	    } else {
	        push @entry, $_;
	    }
	    if (/^#/) {
	    	chomp;
	    	$comment = $_;
		$comment =~ s/^#\s*//;
	    } elsif (/^\{/) {
		$name = undef;
		$comment = undef;
	    } elsif (/^SPEED/) {
	    	chomp;
		s/^SPEED\s*//;
		if ($comment) {
		    $speedStart = $lineNumber - 1 unless $speedStart;
		    push @speeds, "$_;$comment";
		} else {
		    $speedStart = $lineNumber unless $speedStart;
		    push @speeds, $_;
		}
		$speedEnd = $lineNumber;
		$comment = undef;
	    } else {
		$comment = undef;
	    }
    	    if ($comment and not $name) {
		$name = $comment;
		$name =~ s/\s+card\s+/ / unless $name =~ s/\s+card\s*$//;
    	    	$comment = undef;
	    }
	    $lineNumber++;
	}
	push @gdevs, {data => [@entry],
                      name => $name,
                      speeds => [@speeds],
		      type => $type,
		      subtype => $subType,
		      speedstart => $speedStart,
		      speedend => $speedEnd,
		      present =>
                      ($type and exists $exists{"$type:$subType"}) ?
                            $exists{"$type:$subType"} : undef};

	foreach (@ALLOWED) {
	    $allowed{$_} = 1;
	}

        $index = 0;
        foreach $gdevEntry (@gdevs) {
            next unless $gdevEntry->{type};
            next unless $exists{"$gdevEntry->{type}:$gdevEntry->{subtype}"};
            foreach (@{$exists{"$gdevEntry->{type}:$gdevEntry->{subtype}"}}) {
                $gdevIndex[$_] = $index;
            }
        } continue {
            $index++;
        }

	@contents = $telnet->cmd ('cat /gryphon/etc/speed.data');
	if (@contents > 1) {
            foreach (@contents) {
        	chomp;
        	next if /^\s*#/;
        	next if /^\s*$/;
        	($type, $subType, @presets) = split /,/;
        	map {$_ = oct $_ if /^0/} ($type, $subType);
        	next unless $allowed{$type};
        	$presets{"$type:$subType"} = [@presets];
            }
	} else {
	    @contents = ();
	    foreach (@gdevs) {
	    	next unless $_->{type};
		($type, $subType) = ($_->{type}, $_->{subtype});
		next unless $allowed{$type};
                # setting this empty causes the buttons to be pressed
                # somehow which causes $changed to be set to 1.  To
                # change the behaviour, populate the anonymous array with
                # whatever default values you want.  ie [1, 1, 1, 1]
		$presets{"$type:$subType"} = [];
		push @contents, sprintf ('0x%02X,0x%02X', $type, $subType);
	    }
	}
	@speedData = @contents;
	
        $index = 0;
        foreach (@gdevs) {
            if ($_->{present} and $allowed{$_->{type}}) {
                $menuButton->command (-label => $_->{name},
                        -command => [sub { 
                        my $index = shift;
                        $gdevsName = $gdevs[$index]{name};
                        show ($index, 0);
                }, $index]);
                if ($gdevsName eq $EMPTY_ENTRY) {
                    $gdevsName = $_->{name};
                    show ($index, 0);
                    $state = @{$gdevs[$index]{speeds}}
                            > 1 ? 'normal' : 'disabled';

                }
            }
            $index++;
        }
        return unless $state;


	$menu = $MainWin->Menu(-tearoff => 0, -background => '#EEB',
    		-activebackground => '#DDA');
	$menu->add('command', -label => "Edit entry...", -state => 'normal',
    		-underline => 0, -command => [\&editEntry, $list] );
	$menu->add('command', -label => "Delete entry",
	    	-state => $state, -underline => 0, -command =>
        	[\&deleteEntry, $list]);
	$menu->add('command', -label => "New entry", -underline => 0, -command => 
      		[\&addEntry, $list]);
    	$list->bind ('<Button-3>' => sub {
	    	$list->selectionClear;
		$list->selectionSet ($list->nearest ($list->pointery - $list->rooty));
    	    	$menu->Popup(-popover => 'cursor', -popanchor => 'nw');
		});
        $list->bind ('<Delete>' => [\&deleteEntry, $list]);
        $list->bind ('<Control-d>' => [\&deleteEntry, $list]);
        $list->bind ('<Control-e>' => [\&editEntry, $list]);
        $list->bind ('<Control-n>' => [\&addEntry, $list]);

        $list->focus;
        $list->selectionSet ('0');

    } else {
        $configMenu->configure (-state => 'normal');
        $configMenu->configure (-foreground => '#007');
        if ($changed) {
            my ($response, @options);

	    if ($win) {
    	        $win->deiconify;
    	        $win->raise;
	        return;
	    }
            if (Exists $MainWin) {
    	        $win = $MainWin->Toplevel (-title => 'Save data file and disconnect?');
                @options = qw /Yes No Cancel/;
            }

	    $win->OnDestroy (sub {$win = undef});
	    $win->Label (-text => 'Save the data file on the Gryphon')->
	    	    pack (-side => 'top');
	    $win->Label (-text => 'before disconnecting?')->pack (-side => 'top');
	    my $frame = $win->Frame(-relief => 'groove', -borderwidth => 2)->
	    	    pack(-side => 'top');
	    foreach (@options) {
	        $frame->Button (-text => $_, -command => 
	    	        [sub {$response = shift;},$_])->pack(-side => 'left',
		        -pady => 5, -padx => 13);
	    }
	    $win->waitVariable (\$response);
	    $win->destroy;
	    $win = undef;
	    $MainWin->update;
	    if ($response eq 'Cancel') {
                $online = 1;
                $onlineInd->configure (-selectcolor => 'green');
	        return;
            }
            saveDataFile () if $response eq 'Yes';
            $changed = 0;
            $saveMenu->configure (-state => 'disabled');
        }
	$onlineInd->configure(-selectcolor => '#AAF');
        $onlineInd->configure(-label => "Connect to $ip_address");
	$_ = $MainWin->cget (-title);
	s/\S+\s+\S+$/Offline/;
	$widget->title ($_);
        $status = '';
        foreach (@changeAddr) {
            $_->configure (-state => 'normal');
        }
        $gdevsName = $EMPTY_ENTRY;
        $menuButton->cget (-menu)->delete (0, 'end');
        @gdevs = ();
        map {$_->destroy;} $buttonPanel->children;
	@startupIndex = ();
        @channelButtons = ();
        @speedButtons = ();
        $list->delete ('all');
	$menu = undef;
	$list->bind ('<Button-3>', undef);
    }
    
}

sub enterButton{
    my ($widget, $type, $speed) = @_;
    my ($data, $desc, $value1, $value2, $value3, $value4, $bitRate);

    $_ = ${$widget->cget (-textvariable)};
    if ($_) {
        $_ = $speed->[$_ - 1];
        ($data, $desc) = split /;/;
        $desc = '' unless $desc;
    } else {
        $data = '';
        $desc = 'undefined';
    }
    if ($type == &GCAN) {
        $status = bitRateFromBTRs (split / /, $data ) .
                " bps    btrs = $data    $desc"
    } elsif ($type == &GKWP2000) {
        ($value1, $value2) = split / /, $data;
        $bitRate = int (1_000_000 / ((hex $value2) * 256 + (hex $value1)) +.5);
        $bitRate = ::commify ($bitRate);
        $status = "$bitRate bps    ioctl values = $data    $desc";
    } elsif ($type == &GLIN) {
        ($value1, $value2) = split / /, $data;
        $bitRate = (hex $value2) * 256 + hex $value1;
        $bitRate = ::commify ($bitRate);
        $status = "$bitRate bps    ioctl values = $data    $desc";
    } elsif ($type == &GSCI) {
        ($value1, $value2, $value3, $value4) = split / /, $data;
        $bitRate = 0;
        foreach ($value4, $value3, $value2, $value1) {
            $bitRate = $bitRate * 256 + hex $_;
        }
        $bitRate = int (1_152_000 / $bitRate + .5);
        $bitRate = ::commify ($bitRate);
        $status = "$bitRate bps    ioctl values = $data    $desc";
    } elsif ($type == &GVISTNBUS) {
        $status = "Operation: $desc";
    } else {
        $status = 'Don\'t know how to calculate bps';
    }
}


sub bitRateFromBTRs {
    my ($btr0, $btr1) = @_;
    my ($brp, $brp1, $tseg1, $tseg2, $bitRate);

    $brp = hex($btr0) & 0x3F;
    $brp1 = $brp + 1;
    $tseg1 = hex($btr1) & 0x0F;
    $tseg2 = (hex($btr1) & 0x70) >> 4;
    $bitRate = 16_000_000 / (2 * $brp1 * (3 + $tseg1 + $tseg2));
    $bitRate = ::commify (sprintf '%.2f', $bitRate);
    $bitRate =~ s/\.00//;
    return $bitRate;
}


sub quit {
    my ($response, @options);
    saveConfiguration ($configFilename) if $modified;
    if ($changed) {
	if ($win) {
    	    $win->deiconify;
    	    $win->raise;
	    return;
	}
        if (Exists $MainWin) {
    	    $win = $MainWin->Toplevel (-title => 'Save data file and exit?');
            @options = qw /Yes No Cancel/;
            $exitInProgress = 1;
        } elsif ($exitInProgress) {
            return;
        } else {
    	    $win = new MainWindow (-title => 'Save data file and exit?');
            @options = qw /Yes No/;
        }
        
	$win->OnDestroy (sub {$win = undef});
	$win->Label (-text => 'Save the data file on the Gryphon')->
	    	pack (-side => 'top');
	$win->Label (-text => 'before exiting?')->pack (-side => 'top');
	my $frame = $win->Frame(-relief => 'groove', -borderwidth => 2)->
	    	pack(-side => 'top');
	foreach (@options) {
	    $frame->Button (-text => $_, -command => 
	    	    [sub {$response = shift;},$_])->pack(-side => 'left',
		    -pady => 5, -padx => 13);
	}
	$win->waitVariable (\$response);
	$win->destroy;
	$win = undef;
	$MainWin->update;
	if ($response eq 'Cancel') {
            $exitInProgress = 0;
	    return;
        }
        exit unless $response eq 'Yes';
        saveDataFile ();
    }
    exit;
}
}

sub saveDataFile {
    my ($card, @lines, @speeds, $ftp, $type, $subtype, @channels, $index);

    unless (open OUTPUT, ">$tempLocation") {
        my ($return, $path);
        my @dirs = split '/', $tempLocation;

        pop @dirs;
        unless ($dirs[0]) {
            shift @dirs;
            $dirs[0] = "/$dirs[0]";
        }
        $path = '';
        foreach (@dirs) {
            $path .= $path ? "/$_" : $_;
            $return = mkdir $path;
            next if $return == 1;
            next if $! =~ /exists$/;
            $return = -1;
            last;
        }
        if ($return == -1) {
            $MainWin->Dialog (-title => 'File creation error',
                    -text => "Unable to create directory for output file,\n$path\n$!\n",
                    -buttons => ['OK'], -bitmap => 'error')->Show;
            return;
        }
        unless (open OUTPUT, ">$tempLocation") {
            $MainWin->Dialog (-title => 'File creation error',
                    -text => "Unable to create output file,\n$tempLocation\n$!\n",
                    -buttons => ['OK'], -bitmap => 'error')->Show;
            return;
        }
    }
    unless ($ftp = new Net::FTP ($ip_address, -timeout => 30)) {
        $MainWin->Dialog (-title => 'FTP connection error',
                -text => "Unable to establish an FTP connection\nwith $ip_address\n$@\n",
                -buttons => ['OK'], -bitmap => 'error')->Show;
        return;
    }
    unless ($ftp->login ($username, $password)) {
        $MainWin->Dialog (-title => 'FTP login error',
                -text => "Unable to login to the Gryphon via ftp\nwith $password\n",
                -buttons => ['OK'], -bitmap => 'error')->Show;
        return;
    }

    foreach (@speedData) {
        if (/^\s*0x[0-9a-fA-F]{2}/){
            @channels = ();
            ($type, $subtype, @channels) = split /,/;
            map {$_ = oct $_ if /^0/} ($type, $subtype);
            foreach my $gdevEntry (@gdevs) {
                next unless $gdevEntry->{present};
                next unless $type == $gdevEntry->{type} &&
                        $subtype == $gdevEntry->{subtype};
                $index = 0;
                foreach my $chan (@{$gdevEntry->{present}}) {
                    last unless $startupIndex[$chan];
                    $channels[$index] = $startupIndex[$chan];
                    $index++;
                }
            }
            if (@channels) {
                $_ = sprintf ('0x%02X,0x%02X,', $type, $subtype) . join ',', @channels;
            } else {
                $_ = sprintf ('0x%02X,0x%02X', $type, $subtype);
            }
        }
        $_ .= "\n";
    }
    print OUTPUT @speedData;
    close OUTPUT;
    chomp @speedData;
    $telnet->cmd ('wpflashoff') or goto bail;
    $ftp->put ($tempLocation, '/gryphon/etc/speed.data');
    $telnet->cmd ('wpflashon') or goto bail;

    unless (open OUTPUT, ">$tempLocation") {
        $MainWin->Dialog (-title => 'File creation error',
                -text => "Unable to create output file,\n$tempLocation\n$!\n",
                -buttons => ['OK'], -bitmap => 'error')->Show;
        return;
    }

    foreach $card (@gdevs) {
        @lines = @{$card->{data}};
        @speeds = @{$card->{speeds}};
        foreach (@speeds) {
            s/(.+);(.+)/# $2;SPEED $1/ or $_ = "SPEED $_";
        }
        @speeds = split /;/, (join ';', @speeds);
        foreach (@speeds) {
            s/$/\n/;
        }
        if ($card->{speedstart}) {
            splice @lines, $card->{speedstart},
                    $card->{speedend} - $card->{speedstart} + 1, @speeds;
        }
        print OUTPUT @lines;
    }
    close OUTPUT;
    $telnet->cmd ('wpflashoff') or goto bail;
    $ftp->put ($tempLocation, '/gryphon/etc/gdevs');
    $ftp->close;
    $ftp = undef;
    $telnet->cmd ('wpflashon') or goto bail;
    $changed = 0;
    $saveMenu->configure (-state => 'disabled') if $saveMenu;
    unlink $tempLocation;
}

{
my (@temp);
sub getAddress {
    my ($ip_addr, $user, $pass, $boxes, $row, $ts, $df, $of);

    if ($addrWin) {
    	$addrWin->deiconify;
    	$addrWin->raise;
#    	$addrWin->focus;
    } else {
        @temp = ($ip_address, $password);
        $row = 0;
        $addrWin = $MainWin->Toplevel(-title => 'Configuration Information');

        $_ = $addrWin->Frame->pack (-side => 'top');
        $_->Label (-text => "Address of\nGryphon")->
    	        grid (-column => 0, -row => $row, -pady =>5, -padx => 4);

        push @changeAddr, ($ip_addr = $_->Entry(-textvariable => \$temp[0],
	        -width => 18)-> 
    	        grid (-column => 1, -row => $row++, -pady =>5, -padx => 4));

        $_->Label (-text => "root\nPassword")->
    	        grid (-column => 0, -row => $row, -pady =>5, -padx => 4);

        push @changeAddr, ($pass = $_->Entry(-textvariable => \$temp[1],
                -show => '*', -width => 18)-> 
    	        grid (-column => 1, -row => $row++, -pady =>5, -padx => 4));

        $_ = $addrWin->Frame->pack (-side => 'top', -fill => 'x', -pady => 8);
        $_->Button (-text => 'Ok', -width => 7,
	        -command => sub {
                    ($ip_address, $password) = @temp;
                    $addrWin->destroy;
                    $modified = 1;
                    })->
	        pack ( -side => 'left', -pady => 5, -expand => 1);

        $_->Button (-text => 'Cancel', -width => 7,
	        -command => sub {$addrWin->destroy;})->
	        pack ( -side => 'left', -pady => 5, -expand => 1);

        $addrWin->bind ('<KeyPress-Return>',
                sub {
                    ($ip_address, $password) = @temp;
                    $addrWin->destroy;
                    $modified = 1;
                    });
        $addrWin->OnDestroy (sub {$addrWin = undef;
                if ($ip_address) {
                    $onlineInd->configure(-state => 'normal');
                    $onlineInd->configure(-label => "Connect to $ip_address");
                    @changeAddr = ();
                }
                });
        $ip_addr->focus;
        $ip_addr->selectionRange (0, 'end');

        if ($online) {
            foreach (@changeAddr) {
                $_->configure (-state => 'disabled');
            }
        }
    }
}
}

{
my ($index, $select);
sub show {
    ($index, $select) = @_;
    my ($row, $col, $entry, $data, $desc, @saveSelection, $column, @labels);
    my ($numberCols, $currentValue, $trialValue); 
    my $gdevEntry = $gdevs[$index];

    @saveSelection = defined $select ? ($select) : $list->info ('selection');
#print Dumper @saveSelection;
    $list->delete ('all');
    $row = 0;
    foreach $entry (@{$gdevEntry->{speeds}}) {
        $list->add ($row);
        ($data, $desc) = split /;/, $entry;
        $col = 0;
        foreach ($row + 1, $data, $desc) {
            $list->itemCreate ($row, $col++, -text => $_);
        }
        $row++;
    }
    if ($menu) {
        if ($row > 1) {
            $menu->entryconfigure ('Delete entry', -state => 'normal');
        } else {
            $menu->entryconfigure ('Delete entry', -state => 'disabled');
        }
    }
    $list->selectionSet ($saveSelection[0]) if @saveSelection;
    $menu->entryconfigure (1, -state => 'disabled') if $row <= 1 and $menu;

#print Dumper @startupIndex;
    foreach my $chan (@{$gdevEntry->{present}}) {
        if (defined $startupIndex[$chan]) {
            $startupIndex[$chan] = @{$gdevEntry->{speeds}} if
                    $startupIndex[$chan] > @{$gdevEntry->{speeds}};
        }
    }
    return unless defined $select;

    #
    # Setup the initial and current speed index menu buttons
    #
    map {$_->gridForget;} @channelButtons if @channelButtons;
    map {$_->gridForget;} @speedButtons if @speedButtons;
    @labels = ($buttonPanel->gridSlaves (-row => 0),
            $buttonPanel->gridSlaves (-row => 1));
    map {$_->gridForget;} @labels if @labels;
    
    foreach my $chan (@{$gdevEntry->{present}}) {
        next if defined $startupIndex[$chan];
        $startupIndex[$chan] =
                shift @{$presets{"$gdevEntry->{type}:$gdevEntry->{subtype}"}};
        $channelButtons[$chan-1]->configure (
                -options => [1..@{$gdevEntry->{speeds}}],
                -textvariable => \$startupIndex[$chan]);
        $channelButtons[$chan-1]->cget(-menu)->configure (-postcommand => [sub {
                my ($widget, $entry) = @_;

                $widget->configure (-options =>[1..@{$entry->{speeds}}]);
                }, $channelButtons[$chan-1], $gdevEntry]);
        $channelButtons[$chan-1]->
                bind ('<Enter>', [\&enterButton, $gdevEntry->{type}, $gdevEntry->{speeds}]);
        $channelButtons[$chan-1]->
                bind ('<Leave>', sub {$status = '';});


        $speedButtons[$chan-1]->configure (
                -options => [1..@{$gdevEntry->{speeds}}],
                -textvariable => \$currentIndex[$chan]);
        $speedButtons[$chan-1]->cget(-menu)->configure (-postcommand => [sub {
                my ($widget, $entry) = @_;

                $widget->configure (-options =>[1..@{$entry->{speeds}}]);
                }, $speedButtons[$chan-1], $gdevEntry]);
        $speedButtons[$chan-1]->
                bind ('<Enter>', [\&enterButton, $gdevEntry->{type}, $gdevEntry->{speeds}]);
        $speedButtons[$chan-1]->
                bind ('<Leave>', sub {$status = '';});
        $currentIndex[$chan] = 1;
        if ($gdevEntry->{type} == &GLIN) {
            ($currentValue = $ioctlData[$chan]{currentspeed})
                    =~ s/^0x(\S+)\s+0x(\S+)/$2$1/i;
            $currentValue = hex $currentValue;
        }
        foreach my $speed (@{$gdevEntry->{speeds}}) {
            if ($gdevEntry->{type} == &GLIN) {
                ($trialValue = $speed) =~ s/^0x(\S+)\s+0x(\S+);.+/$2$1/i;
                $trialValue = hex $trialValue;
                last if $currentValue > .96 * $trialValue &&
                        $currentValue < 1.04 * $trialValue;
            } else {
                last if $speed =~ /^$ioctlData[$chan]{currentspeed}/i;
            }
            $currentIndex[$chan]++;
        }
        $currentIndex[$chan] = 0
                if $currentIndex[$chan] > @{$gdevEntry->{speeds}}
    }

    $numberCols = @{$gdevs[$index]{present}};
    $buttonPanel->Label (-text => $numberCols > 1 ? '... Channels ...' :
            'Channel')->grid (-row => 0,
            -column => 1, -columnspan => $numberCols);
    $buttonPanel->gridColumnconfigure ($numberCols + 1, -weight => 1);

    $column = 1;
    foreach my $chan (@{$gdevs[$index]{present}}) {
        $buttonPanel->Label (-text => $chan)->
                grid (-column => $column, -row => 1);
        $channelButtons[$chan-1]->
                grid (-column => $column, -row => 2, -padx => 12);
        $speedButtons[$chan-1]->
                grid (-column => $column, -row => 3, -padx => 12);
        $buttonPanel->gridColumnconfigure ($column, -weight => 0);
        $column++;

    }

}

sub moveEntry {
    my ($widget, $drop) = @_;
    my ($drag, $arrayRef, $step);

    return if $editing;
    ($drag) = $widget->info ('selection');
    return if $drag == $drop;
    if ($drag > $drop) {
        $step = -1;
    } else {
        $step = 1;
    }
    foreach my $chan (@{$gdevs[$index]{present}}) {
        if ($drag == $currentIndex[$chan] - 1) {
            $currentIndex[$chan] = $drop + 1;
        } elsif ($drop == $currentIndex[$chan] - 1) {
            $currentIndex[$chan] -= $step;
        }
    }
    $arrayRef = $gdevs[$index]{speeds};
    for (; $drag != $drop; $drag += $step) {
        ($arrayRef->[$drag], $arrayRef->[$drag + $step]) =
	        ($arrayRef->[$drag + $step], $arrayRef->[$drag]);
    }
    show ($index);
    $widget->selectionClear;
    $widget->selectionSet ($drop);
    $changed = 1;
    $saveMenu->configure (-state => 'normal');
}

sub deleteEntry {
    my $widget = shift;
    my ($entry, $arrayRef, $selected);

    $arrayRef = $gdevs[$index]{speeds};
    return unless @{$gdevs[$index]{speeds}} > 1;
    $selected = $widget->info ('selection');
    for ($entry = $selected; $entry < $#$arrayRef; $entry++) {
    	$arrayRef->[$entry] = $arrayRef->[$entry + 1]
    }
    $arrayRef->[$#$arrayRef] = undef;
    $#$arrayRef--;
    $selected = $#$arrayRef unless $selected <= $#$arrayRef;
    $widget->selectionSet ($selected);
    $changed = 1;
    $saveMenu->configure (-state => 'normal');
    show ($index);
}

sub editEntry {
    my $widget = shift;
    my ($type, $entry, $arrayRef);

    $arrayRef = $gdevs[$index]{speeds};
    $entry = ($widget->info ('selection'))[0];
    $type = $gdevs[$index]{type};
    if ($type == &GCAN) {
    	CanSpeed::editEntry ($widget, $index, $entry);
    } elsif ($type == &GJ1850) {
    } elsif ($type == &GKWP2000) {
        KwpSpeed::editEntry ($widget, $index, $entry);
    } elsif ($type == &GLIN) {
        LinSpeed::editEntry ($widget, $index, $entry);
    } elsif ($type == &GSCI) {
        SciSpeed::editEntry ($widget, $index, $entry);
    }
    show ($index) if @gdevs;
}

sub addEntry {
    my $widget = shift;
    my ($type, $entry, $arrayRef, $lastPath, $col);

    $arrayRef = $gdevs[$index]{speeds};
    $entry = @$arrayRef;
    $type = $gdevs[$index]{type};
    @_ = $widget->info ('child');
    $lastPath = pop;
    $widget->add ($lastPath + 1, -itemtype => 'text');

    $col = 0;
    if ($type == &GCAN) {
        foreach ($lastPath + 2, '0x03 0x1c', 'Description') {
	    $widget->itemCreate ($lastPath + 1, $col, -text, $_);
	    $col++;
        }
        $widget->selectionClear;
        $widget->selectionSet ($lastPath + 1);
    	CanSpeed::editEntry ($widget, $index, $entry, 1);
    } elsif ($type == &GJ1850) {
    } elsif ($type == &GKWP2000) {
        foreach ($lastPath + 2, '0x60 0x00', 'Description') {
	    $widget->itemCreate ($lastPath + 1, $col, -text, $_);
	    $col++;
        }
        $widget->selectionClear;
        $widget->selectionSet ($lastPath + 1);
        KwpSpeed::editEntry ($widget, $index, $entry, 1);
    } elsif ($type == &GLIN) {
        foreach ($lastPath + 2, '0x00 0x4b', 'Description') {
	    $widget->itemCreate ($lastPath + 1, $col, -text, $_);
	    $col++;
        }
        $widget->selectionClear;
        $widget->selectionSet ($lastPath + 1);
        LinSpeed::editEntry ($widget, $index, $entry, 1);
    } elsif ($type == &GSCI) {
        foreach ($lastPath + 2, '0x34 0x00 0x00 0x00', 'Description') {
	    $widget->itemCreate ($lastPath + 1, $col, -text, $_);
	    $col++;
        }
        $widget->selectionClear;
        $widget->selectionSet ($lastPath + 1);
        SciSpeed::editEntry ($widget, $index, $entry, 1);
    }
    show ($index) if @gdevs;
}
}

{
package CanSpeed;
my (@SpeedWin);
my (@pad, %tseg1, %tseg2, %quanta, $radioFrame, $desc);
my ($btr0, $btr1, $brp, $tseg1, $tseg2, $maxRadio, @radioButton, $speedIndex);
my ($bitRate, $sampleMode, $timeQuanta, $sjw, $samplePoint, $jump);
my $oldFreq;

sub editEntry {
    my ($widget, $gdevIndex, $index, $new) = @_;
    
    my ($row);
    my ($Top, $Bottom, $cancel);
    @pad = (qw /-pady 4 -padx 5/);
    %tseg1 = (low => 2, high => 15);
    %tseg2 = (low => 1, high => 7);
    %quanta = (low => 1 + $tseg1{low} + 1 + $tseg2{low} + 1,
            high => 1 + $tseg1{high} + 1 + $tseg2{high} + 1);
    $oldFreq = undef;

    
    if ($SpeedWin[$index]) {
    	$SpeedWin[$index]->deiconify;
    	$SpeedWin[$index]->raise;
	return;
    }

    $editing++;
    $cancel = 1;
    $SpeedWin[$index] = $MainWin->Toplevel();
    $SpeedWin[$index]->title("Edit CAN Speed entry");
    $Top = $SpeedWin[$index]->Frame-> pack (-side => 'top', -pady => 3, -fill => 'x',
    	    -expand => 1);
    $Top->gridColumnconfigure ([0, 1], -weight => 1, -minsize => 250);

    $row = 0;
    $_ = $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'Description')->pack (-side =>'left');
    $_->Entry (-textvariable => \$desc, -width => 35)->pack (-side =>'left');


    $_ = $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    my $entry = $_->BrowseEntry (-label => 'Bits per Second  ', -width => 12,
            -variable => \$bitRate, -state => 'readonly',
            -browsecmd => \&checkBPSentry)-> pack (-side => 'left', @pad);
    $SpeedWin[$index]->bind ('<Button-3>', \&nextBPSentry);

    $radioFrame = $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);

    $_ = $Top->LabFrame (-label => 'Bit Timing Registers', -labelside => 'acrosstop')->
    	    grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'BTR0')->
    	    pack (-side => 'left', @pad);
    $_->Entry (-textvariable => \$btr0, -width => 3)->
    	    pack (-side => 'left', @pad)->
            bind ('<KeyPress>', [\&::checkSingleByteEntry, 255, \&bitRateFromBTRs]);

    $_->Label (-text => '       BTR1')->
    	    pack (-side => 'left', @pad);
    $_->Entry (-textvariable => \$btr1, -width => 3)->
    	    pack (-side => 'left', @pad)->
            bind ('<KeyPress>', [\&::checkSingleByteEntry, 255, \&bitRateFromBTRs]);

    createScale ($Top, 'Baud Rate Prescaler', 0, $row, \$brp, 2, 
            \&bitRateFromBrp, 0, 63);
    createScale ($Top, 'Time Quanta per Bit', 1, $row++, \$timeQuanta, 2,
            \&adjustQuanta, $quanta{low}, $quanta{high});

    createScale ($Top, 'Tseg1', 0, $row, \$tseg1, 2,
            \&bitRateFromTsegs, $tseg1{low}, $tseg1{high});
    createScale ($Top, 'Tseg2', 1, $row++, \$tseg2, 2,
            \&bitRateFromTsegs, $tseg2{low}, $tseg2{high});

    createScale ($Top, 'Sample Point in Percent', 0, $row, \$samplePoint, 2,
            \&adjustSample, 0, 100);
    $jump = createScale ($Top, 'Resync Jump Width (x%)', 1, $row++,
            \$sjw, 2, \&adjustSjw, 0, 3);

    $_ = $Top->LabFrame (-label => 'Sampling Mode', -labelside => 'acrosstop')->
    	    grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Radiobutton (-text => 'One sample', -value => 0,
    	    -variable => \$sampleMode, -command => \&adjustSpl)->
	    pack (-side => 'left', -padx => 15, -pady => 4);
    $_->Radiobutton (-text => 'Three samples', -value => 1,
    	    -variable => \$sampleMode, -command => \&adjustSpl)->
	    pack (-side => 'left', -padx => 15, -pady => 4);

    $Bottom = $SpeedWin[$index]->Frame->pack (-side => 'top', -fill => 'x',
    	    -expand => 1, -ipady => 6, -padx => 4, -pady => 2);
    $Bottom->gridColumnconfigure ([0, 1], -weight => 1);
    $Bottom->Button(-text => 'Cancel', -width => 7,
    	    -command => sub{$SpeedWin[$index]->destroy})->
	    grid(-row => 0, -column => 0, -pady => 3); 
    $Bottom->Button(-text => 'Save', -width => 7,
    	    -command => sub{$cancel = undef; $SpeedWin[$index]->destroy})->
	    grid(-row => 0, -column => 1, -pady => 3); 


    ($btr0, $btr1) = split / /, $widget->itemCget ($index, 1, -text);
    $desc = ($widget->itemCget ($index, 2, -text)) || '';

    sub numerically { $a <=> $b; }

    my ($ps, $tq, %speeds, $index1);

    for ($ps = 1; $ps <= 64; $ps++) {
        for ($tq = $quanta{low}; $tq <= $quanta{high}; $tq++) {
            $_ = 16_000_000 / (2 * $ps * $tq);
            $_ = sprintf '%.2f', $_;
            s/\.00//;
            $speeds{$_}++;
        }
    }

    $maxRadio = 0;
    foreach (sort numerically keys %speeds) {
        $entry->insert ('end', ::commify ($_));
        $maxRadio = $speeds{$_} if $speeds{$_} > $maxRadio;
    }
    for ($index1 = 0; $index1 < $maxRadio; $index1++) {
        $radioButton[$index1] = $radioFrame->Radiobutton (-value => $index1,
                -command => [\&gotoBPSentry, $index1], -variable => \$speedIndex,
                -text => eval $index1 + 1)->
                pack (-side => 'left');
    }

    bitRateFromBTRs ();

    $SpeedWin[$index]->OnDestroy(sub {
    	my ($path, $col);

	if ($cancel) {
	    $widget->delete ('entry', $index) if $new;
	} else {
	    $changed = 1;
            $saveMenu->configure (-state => 'normal');
	    $gdevs[$gdevIndex]{speeds}[$index] = "0x$btr0 0x$btr1;$desc";
	    ::show ($gdevIndex);
	}
    });

    $SpeedWin[$index]->OnDestroy (sub {$SpeedWin[$index] = undef;
    	    $editing--});
    $MainWin->waitVariable (\$gdevsName);
    $SpeedWin[$index]->destroy if $SpeedWin[$index];
}

sub createScale {
    my ($widget, $desc, $col, $row, $var, $width, $funct, $from, $to) = @_;

    $_ = $widget->LabFrame (-label => $desc, -labelside => 'acrosstop')
            ->grid (-column => $col, -row => $row, @pad, -sticky => 'ew');
    $_->Label(-textvariable => $var, -width => $width)->
            pack (-side => 'left', @pad);
    $_->Scale (-from => $from, -to => $to, -showvalue => 0,
    	    -variable => $var, -orient => 'hor', -command => $funct)->
            pack (-side => 'left', -expand => 1, -fill => 'x', @pad);
    return $_;
}

sub bitRateFromBTRs {
    my $brp1;

    $brp = hex($btr0) & 0x3F;
    $sjw = (hex($btr0) & 0xC0) >> 6;
    $brp1 = $brp + 1;
    $tseg1 = hex($btr1) & 0x0F;
    $tseg2 = (hex($btr1) & 0x70) >> 4;
    $sampleMode = (hex($btr1) & 0x80) >> 7;
    $bitRate = 16_000_000 / (2 * $brp1 * (3 + $tseg1 + $tseg2));
    $bitRate = ::commify (sprintf '%.2f', $bitRate);
    $bitRate =~ s/\.00//;
    $timeQuanta = 1 + $tseg1 + 1 + $tseg2 + 1;
    $samplePoint = sprintf ('%.0f', ((1 +  $tseg1 + 1) / $timeQuanta) * 100);
    findBPS ($bitRate);
    rotateBPSentry ();
}

sub bitRateFromTsegs {
    my $brp1;

    $brp = hex($btr0) & 0x3F;
    $brp1 = $brp + 1;
    $btr1 = sprintf '%02X', ((($sampleMode << 3) + $tseg2) << 4) + $tseg1;
    $bitRate = 16_000_000 / (2 * $brp1 * (3 + $tseg1 + $tseg2));
    $bitRate = ::commify (sprintf '%.2f', $bitRate);
    $bitRate =~ s/\.00//;
    $timeQuanta = 1 + $tseg1 + 1 + $tseg2 + 1;
    $samplePoint = sprintf ('%.0f', ((1 +  $tseg1 + 1) / $timeQuanta) * 100);
    findBPS ($bitRate);
    rotateBPSentry ();
    adjustSjw ();
}

sub bitRateFromBrp {
    my $brp1;

    $brp1 = $brp + 1;
    $btr0 = sprintf '%02X', ($sjw << 6) + $brp;
    $bitRate = 16_000_000 / (2 * $brp1 * (3 + $tseg1 + $tseg2));
    $bitRate = ::commify (sprintf '%.2f', $bitRate);
    $bitRate =~ s/\.00//;
    findBPS ($bitRate);
    rotateBPSentry ();
}

sub adjustQuanta {
    my ($oldQuanta);

    $oldQuanta = 1 + $tseg1 + 1 + $tseg2 + 1;
    return if $timeQuanta == $oldQuanta;
    if ($timeQuanta < $oldQuanta) {
    	if ($tseg1 == $tseg1{low}) {
	    $tseg2 = $timeQuanta - $tseg1 - 1 - 2;
	} elsif ($tseg2 == $tseg2{low}) {
	    $tseg1 = $timeQuanta - $tseg2 - 1 - 2;
	} else {
	    $tseg1 = int (($samplePoint / 100) * $timeQuanta - 1.5);
	    $tseg1 = $tseg1{low} if $tseg1 < $tseg1{low};
	    $tseg2 = $timeQuanta - 1 - $tseg1 - 2;
	}
    } else {
    	if ($tseg1 == $tseg1{high}) {
	    $tseg2 = $timeQuanta - $tseg1 - 1 - 2;
	} elsif ($tseg2 == $tseg2{high}) {
	    $tseg1 = $timeQuanta - $tseg2 - 1 - 2;
	} else {
	    $tseg1 = int (($samplePoint / 100) * $timeQuanta - 1.5);
	    $tseg1 = $tseg1{high} if $tseg1 > $tseg1{high};
	    $tseg2 = $timeQuanta - 1 - $tseg1 - 2;
	}
    }
    bitRateFromTsegs ();
}

sub adjustSample {
    my ($newTseg1, $newTseg2);

    $newTseg1 = int (($samplePoint / 100) * $timeQuanta - 1.5);
    $newTseg2 = $timeQuanta - 1 - $newTseg1 - 2;
    if ($newTseg1 == $tseg1 or $newTseg1 < $tseg1{low} or
    	    $newTseg1 > $tseg1{high}) {
        $samplePoint = sprintf ('%.0f', ((1 +  $tseg1 + 1) / $timeQuanta) * 100);
    	return;
    } elsif ($newTseg2 == $tseg2 or $newTseg2 < $tseg2{low} or
    	    $newTseg2 > $tseg2{high}) {
        $samplePoint = sprintf ('%.0f', ((1 +  $tseg1 + 1) / $timeQuanta) * 100);
    	return;
    }
    $tseg1 = $newTseg1;
    $tseg2 = $timeQuanta - 1 - $tseg1 - 2;
    $btr1 = sprintf '%02X', ((($sampleMode << 3) + $tseg2) << 4) + $tseg1;
    adjustSjw ();
}

{
my @validEntries;

sub rotateBPSentry {
    while ("@{$validEntries[$#validEntries]}[0, 1]" ne "$brp $timeQuanta") {
        push @validEntries, [@{shift @validEntries}];
    }
    $speedIndex = $validEntries[$#validEntries][2];
}
        
sub gotoBPSentry {
    my $newIndex = shift;
    my ($tseg1Local, $tseg2Local);

    while (@{$validEntries[$#validEntries]}[2] != $newIndex) {
        push @validEntries, [@{shift @validEntries}];
    }
    ($brp, $timeQuanta, $speedIndex) = @{$validEntries[$#validEntries]};
    $tseg2Local = $tseg2{low};
    $tseg1Local = $timeQuanta - 1 - $tseg2Local - 2;
    if ($tseg1Local > $tseg1{high}) {
        $tseg1Local = $tseg1{high};
        $tseg2Local = $timeQuanta - 1 - $tseg1Local - 2;
    }
    ($tseg1, $tseg2) = ($tseg1Local, $tseg2Local);
    $samplePoint = sprintf ('%.0f', ((1 +  $tseg1 + 1) / $timeQuanta) * 100);
    $btr1 = sprintf '%02X', ((($sampleMode << 3) + $tseg2) << 4) + $tseg1;
    adjustSjw ();
}
        
sub checkBPSentry {
    findBPS ($bitRate);
    updateBPS ();
    bitRateFromBrp ();
    adjustSjw ();
}

sub nextBPSentry {
    my $widget = shift;

    updateBPS ();
    bitRateFromBrp ();
    adjustSjw ();
}

sub findBPS {
    my $freq = shift;
    my ($temp, $ps, $tq, $index);

    return if $oldFreq and $freq eq $oldFreq;
    $oldFreq = $freq;
    @validEntries = ();
    $freq =~ s/,//g;
    foreach ($radioFrame->packSlaves) {
        $_->packForget;
    }
    $index = 0;
    for ($ps = 1; $ps <= 64; $ps++) {
        for ($tq = $quanta{low}; $tq <= $quanta{high}; $tq++) {
            $temp = 16_000_000 / (2 * $ps * $tq);
            if (abs ($freq - $temp) < .5) {
                $radioButton[$index]->pack (-side => 'left', -padx => 4)
                        if $radioButton[0];
                push @validEntries, [$ps - 1, $tq, $index];
                $index++;
            }
        }
    }
}

sub updateBPS {
    my ($tseg1Local, $tseg2Local);

    return unless @validEntries;
    ($brp, $timeQuanta, $speedIndex) = @{shift @validEntries};
    push @validEntries, [$brp, $timeQuanta, $speedIndex];
    $tseg2Local = $tseg2{low};
    $tseg1Local = $timeQuanta - 1 - $tseg2Local - 2;
    if ($tseg1Local > $tseg1{high}) {
        $tseg1Local = $tseg1{high};
        $tseg2Local = $timeQuanta - 1 - $tseg1Local - 2;
    }
    ($tseg1, $tseg2) = ($tseg1Local, $tseg2Local);
    $samplePoint = sprintf ('%.0f', ((1 +  $tseg1 + 1) / $timeQuanta) * 100);
    $btr1 = sprintf '%02X', ((($sampleMode << 3) + $tseg2) << 4) + $tseg1;
} }

sub adjustSjw {
    my $pct;

    $sjw = $tseg2 if $sjw > $tseg2;
    $btr0 = sprintf '%02X', ($sjw << 6) + $brp;
    $pct = sprintf '%.0f', (($sjw + 1) / $timeQuanta) * 100;
    $jump->configure (-label => "Resync Jump Width ($pct%)");
}

sub adjustSpl {
    $btr1 = sprintf '%02X', ((($sampleMode << 3) + $tseg2) << 4) + $tseg1;
}

}

{
package KwpSpeed;
my @SpeedWin;
my (@pad, $desc, $value1, $value2, $bitRate);
sub editEntry {
    my ($widget, $gdevIndex, $index, $new) = @_;
    
    my ($row, $col);
    my ($Top, $Bottom, $cancel);
    @pad = (qw /-pady 4 -padx 5/);
    
    if ($SpeedWin[$index]) {
    	$SpeedWin[$index]->deiconify;
    	$SpeedWin[$index]->raise;
	return;
    }

    $editing++;
    $cancel = 1;
    $SpeedWin[$index] = $MainWin->Toplevel();
    $SpeedWin[$index]->title("Edit KWP 2000 Speed entry");
    $Top = $SpeedWin[$index]->Frame-> pack (-side => 'top', -pady => 3, -fill => 'x',
    	    -expand => 1);
    $Top->gridColumnconfigure ([0, 1], -weight => 1, -minsize => 250);

    $row = 0;
    $_ = $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'Description')->pack (-side =>'left');
    $_->Entry (-textvariable => \$desc, -width => 35)->pack (-side =>'left');


    $_ = $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'Bits per Second  ')-> pack (-side => 'left', @pad);
    my $entry = $_->Entry (-width => 12, -textvariable => \$bitRate)->
            pack (-side => 'left', @pad);
    $entry->bind ('<KeyPress>', \&computeValues);

    $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);

    $_ = $Top->LabFrame (-label => 'IOCTL values', -labelside => 'acrosstop')->
    	    grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'Value 1')->
    	    pack (-side => 'left', @pad);
    $_->Entry (-textvariable => \$value1, -width => 3)->
    	    pack (-side => 'left', @pad)->
            bind ('<KeyPress>', [\&::checkSingleByteEntry, 255, \&bitRateFromValues]);

    $_->Label (-text => '       Value 2')->
    	    pack (-side => 'left', @pad);
    $_->Entry (-textvariable => \$value2, -width => 3)->
    	    pack (-side => 'left', @pad)->
            bind ('<KeyPress>', [\&::checkSingleByteEntry, 255, \&bitRateFromValues]);

    $Bottom = $SpeedWin[$index]->Frame->pack (-side => 'top', -fill => 'x',
    	    -expand => 1, -ipady => 6, -padx => 4, -pady => 2);
    $Bottom->gridColumnconfigure ([0, 1], -weight => 1);
    $Bottom->Button(-text => 'Cancel', -width => 7,
    	    -command => sub{$SpeedWin[$index]->destroy})->
	    grid(-row => 0, -column => 0, -pady => 3); 
    $Bottom->Button(-text => 'Save', -width => 7,
    	    -command => sub{$cancel = undef; $SpeedWin[$index]->destroy})->
	    grid(-row => 0, -column => 1, -pady => 3); 


    ($value1, $value2) = split / /, $widget->itemCget ($index, 1, -text);
    foreach ($value1, $value2) {
        s/^0x//i;
    }
    $desc = ($widget->itemCget ($index, 2, -text)) || '';

    bitRateFromValues ();

    $SpeedWin[$index]->OnDestroy(sub {
    	my ($path, $col);

	if ($cancel) {
	    $widget->delete ('entry', $index) if $new;
	} else {
	    $changed = 1;
            $saveMenu->configure (-state => 'normal');
	    $gdevs[$gdevIndex]{speeds}[$index] = "0x$value1 0x$value2;$desc";
	    ::show ($gdevIndex);
	}
    });

    $SpeedWin[$index]->OnDestroy (sub {$SpeedWin[$index] = undef;
    	    $editing--});
    $MainWin->waitVariable (\$gdevsName);
    $SpeedWin[$index]->destroy if $SpeedWin[$index];
}

sub bitRateFromValues {
    $bitRate = int (1_000_000 / ((hex $value2) * 256 + (hex $value1)) +.5);
    $bitRate = ::commify ($bitRate);
}

sub computeValues {
    $_ = $bitRate;
    s/,//g;
    $_ = int(1_000_000 / $_ + .5);
    $value1 = $_ % 256;
    $value2 = int ($_ / 256);
    $value2 = 255 if $value2 > 255;
    $_ = sprintf '%02X %02X', $value1, $value2;
    ($value1, $value2) = split;
}
}

{
package LinSpeed;
my @SpeedWin;
my (@pad, $desc, $value1, $value2, $bitRate);
sub editEntry {
    my ($widget, $gdevIndex, $index, $new) = @_;
    
    my ($row, $col);
    my ($Top, $Bottom, $cancel);
    @pad = (qw /-pady 4 -padx 5/);
    
    if ($SpeedWin[$index]) {
    	$SpeedWin[$index]->deiconify;
    	$SpeedWin[$index]->raise;
	return;
    }

    $editing++;
    $cancel = 1;
    $SpeedWin[$index] = $MainWin->Toplevel();
    $SpeedWin[$index]->title("Edit LIN Speed entry");
    $Top = $SpeedWin[$index]->Frame-> pack (-side => 'top', -pady => 3, -fill => 'x',
    	    -expand => 1);
    $Top->gridColumnconfigure ([0, 1], -weight => 1, -minsize => 250);

    $row = 0;
    $_ = $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'Description')->pack (-side =>'left');
    $_->Entry (-textvariable => \$desc, -width => 35)->pack (-side =>'left');


    $_ = $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'Bits per Second  ')-> pack (-side => 'left', @pad);
    my $entry = $_->Entry (-width => 12, -textvariable => \$bitRate)->
            pack (-side => 'left', @pad);
    $entry->bind ('<KeyPress>', \&computeValues);

    $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);

    $_ = $Top->LabFrame (-label => 'IOCTL values', -labelside => 'acrosstop')->
    	    grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'Value 1')->
    	    pack (-side => 'left', @pad);
    $_->Entry (-textvariable => \$value1, -width => 3)->
    	    pack (-side => 'left', @pad)->
            bind ('<KeyPress>', [\&::checkSingleByteEntry, 255, \&bitRateFromValues]);

    $_->Label (-text => '       Value 2')->
    	    pack (-side => 'left', @pad);
    $_->Entry (-textvariable => \$value2, -width => 3)->
    	    pack (-side => 'left', @pad)->
            bind ('<KeyPress>', [\&::checkSingleByteEntry, 255, \&bitRateFromValues]);

    $Bottom = $SpeedWin[$index]->Frame->pack (-side => 'top', -fill => 'x',
    	    -expand => 1, -ipady => 6, -padx => 4, -pady => 2);
    $Bottom->gridColumnconfigure ([0, 1], -weight => 1);
    $Bottom->Button(-text => 'Cancel', -width => 7,
    	    -command => sub{$SpeedWin[$index]->destroy})->
	    grid(-row => 0, -column => 0, -pady => 3); 
    $Bottom->Button(-text => 'Save', -width => 7,
    	    -command => sub{$cancel = undef; $SpeedWin[$index]->destroy})->
	    grid(-row => 0, -column => 1, -pady => 3); 


    ($value1, $value2) = split / /, $widget->itemCget ($index, 1, -text);
    foreach ($value1, $value2) {
        s/^0x//i;
    }
    $desc = ($widget->itemCget ($index, 2, -text)) || '';

    bitRateFromValues ();

    $SpeedWin[$index]->OnDestroy(sub {
    	my ($path, $col);

	if ($cancel) {
	    $widget->delete ('entry', $index) if $new;
	} else {
	    $changed = 1;
            $saveMenu->configure (-state => 'normal');
	    $gdevs[$gdevIndex]{speeds}[$index] = "0x$value1 0x$value2;$desc";
	    ::show ($gdevIndex);
	}
    });

    $SpeedWin[$index]->OnDestroy (sub {$SpeedWin[$index] = undef;
    	    $editing--});
    $MainWin->waitVariable (\$gdevsName);
    $SpeedWin[$index]->destroy if $SpeedWin[$index];
}

sub bitRateFromValues {
    $bitRate = (hex $value2) * 256 + hex $value1;
    $bitRate = ::commify ($bitRate);
}

sub computeValues {
    $_ = $bitRate;
    s/,//g;
    $value1 = $_ % 256;
    $value2 = int ($_ / 256);
    $value2 = 255 if $value2 > 255;
    $_ = sprintf '%02X %02X', $value1, $value2;
    ($value1, $value2) = split;
}
}


{
package SciSpeed;
my @SpeedWin;
my (@pad, $desc, $value1, $value2, $value3, $value4, $bitRate);
sub editEntry {
    my ($widget, $gdevIndex, $index, $new) = @_;
    
    my ($row, $col);
    my ($Top, $Bottom, $cancel);
    @pad = (qw /-pady 4 -padx 5/);
    
    if ($SpeedWin[$index]) {
    	$SpeedWin[$index]->deiconify;
    	$SpeedWin[$index]->raise;
	return;
    }

    $editing++;
    $cancel = 1;
    $SpeedWin[$index] = $MainWin->Toplevel();
    $SpeedWin[$index]->title("Edit SCI Speed entry");
    $Top = $SpeedWin[$index]->Frame-> pack (-side => 'top', -pady => 3, -fill => 'x',
    	    -expand => 1);
    $Top->gridColumnconfigure ([0, 1], -weight => 1, -minsize => 250);

    $row = 0;
    $_ = $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'Description')->pack (-side =>'left');
    $_->Entry (-textvariable => \$desc, -width => 35)->pack (-side =>'left');


    $_ = $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'Bits per Second  ')-> pack (-side => 'left', @pad);
    my $entry = $_->Entry (-width => 12, -textvariable => \$bitRate)->
            pack (-side => 'left', @pad);
    $entry->bind ('<KeyPress>', \&computeValues);

    $Top->Frame->
            grid (-column => 0, -row => $row++, @pad, -columnspan => 2);

    $_ = $Top->LabFrame (-label => 'IOCTL values', -labelside => 'acrosstop')->
    	    grid (-column => 0, -row => $row++, @pad, -columnspan => 2);
    $_->Label (-text => 'Value 1')->
    	    grid (-column => 0, -row => 0, @pad);
    $_->Entry (-textvariable => \$value1, -width => 3)->
    	    grid (-column => 1, -row => 0, @pad)->
            bind ('<KeyPress>', [\&::checkSingleByteEntry, 255, \&bitRateFromValues]);

    $_->Label (-text => '       Value 2')->
    	    grid (-column => 2, -row => 0, @pad);
    $_->Entry (-textvariable => \$value2, -width => 3)->
    	    grid (-column => 3, -row => 0, @pad)->
            bind ('<KeyPress>', [\&::checkSingleByteEntry, 255, \&bitRateFromValues]);

    $_->Label (-text => 'Value 3')->
    	    grid (-column => 0, -row => 1, @pad);
    $_->Entry (-textvariable => \$value3, -width => 3)->
    	    grid (-column => 1, -row => 1, @pad)->
            bind ('<KeyPress>', [\&::checkSingleByteEntry, 255, \&bitRateFromValues]);

    $_->Label (-text => '       Value 4')->
    	    grid (-column => 2, -row => 1, @pad);
    $_->Entry (-textvariable => \$value4, -width => 3)->
    	    grid (-column => 3, -row => 1, @pad)->
            bind ('<KeyPress>', [\&::checkSingleByteEntry, 255, \&bitRateFromValues]);

    $Bottom = $SpeedWin[$index]->Frame->pack (-side => 'top', -fill => 'x',
    	    -expand => 1, -ipady => 6, -padx => 4, -pady => 2);
    $Bottom->gridColumnconfigure ([0, 1], -weight => 1);
    $Bottom->Button(-text => 'Cancel', -width => 7,
    	    -command => sub{$SpeedWin[$index]->destroy})->
	    grid(-row => 0, -column => 0, -pady => 3); 
    $Bottom->Button(-text => 'Save', -width => 7,
    	    -command => sub{$cancel = undef; $SpeedWin[$index]->destroy})->
	    grid(-row => 0, -column => 1, -pady => 3); 


    ($value1, $value2, $value3, $value4) = split / /,
            $widget->itemCget ($index, 1, -text);
    foreach ($value1, $value2, $value3, $value4) {
        s/^0x//i;
    }
    $desc = ($widget->itemCget ($index, 2, -text)) || '';

    bitRateFromValues ();

    $SpeedWin[$index]->OnDestroy(sub {
    	my ($path, $col);

	if ($cancel) {
	    $widget->delete ('entry', $index) if $new;
	} else {
	    $changed = 1;
            $saveMenu->configure (-state => 'normal');
	    $gdevs[$gdevIndex]{speeds}[$index] =
                    "0x$value1 0x$value2 0x$value3 0x$value4;$desc";
	    ::show ($gdevIndex);
	}
    });

    $SpeedWin[$index]->OnDestroy (sub {$SpeedWin[$index] = undef;
    	    $editing--});
    $MainWin->waitVariable (\$gdevsName);
    $SpeedWin[$index]->destroy if $SpeedWin[$index];
}

sub bitRateFromValues {
    $bitRate = 0;
    foreach ($value4, $value3, $value2, $value1) {
        $bitRate = $bitRate * 256 + hex $_;
    }
    if ($bitRate) {
        $bitRate = int (1_152_000 / $bitRate + .5);
        $bitRate = ::commify ($bitRate);
    } else {
        $bitRate = '';
    }
}

sub computeValues {
    $_ = $bitRate;
    s/,//g;
    if ($_) {
        $_ = 1_152_000 / $_;
        $_ = sprintf '%08X', $_;
        ($value4, $value3, $value2, $value1) = /^(..)(..)(..)(..)$/;
    } else {
        $value1 = $value2 = $value3 = $value4 = '';
    }
}
}


sub checkSingleByteEntry {
    my ($widget, $limit, $function) = @_;
    my $value = $widget->get;
    my $test;
    
    if ($value =~ /[^a-fA-F0-9]+/) {
	print "\a";
	$widget->delete($widget->index('insert') -1);
	return;
    }
    if ($limit) {
	$test = hex $value;
	if ($test > $limit) {
	    print "\a";
	    $_ = $widget->index('insert') - 1;
	    $widget->delete($_);
	}
    }
    &$function if $function;
}

sub changeSpeed {
    my ($gdevEntry, $channel, $index, $ioctlEntry) = @_;
    my ($newSpeed, $oldSpeed, @data, $result, $reply, $entity);

    if ($gdevEntry->{type} == &GVISTNBUS) {
        $entity = 'mode';
    } else {
        $entity = 'speed';
    }
    $newSpeed = (split ';', $gdevEntry->{speeds}[$index - 1])[0];
    $oldSpeed = $ioctlEntry->{currentspeed};
    return if lc $newSpeed eq lc $oldSpeed;
    $ioctlEntry = $ioctlData[$channel];
    @data = split /\s+/, $newSpeed;
    @data = map {
        s /^0x//i;
        $_ = hex;
    } @data;
    ($result, $reply) = $gryphon->cmdSend (gcDest => &SD_CARD,
            gcDestChan => $channel, cmd => &CMD_CARD_IOCTL,
            data => [$ioctlEntry->{setspeed}, @data],
            dataRecipe => "NC$ioctlEntry->{size}");
    if ($result) {
        $status = "Unable to change $entity: $@";
    } else {
        $status = "Successful $entity change on channel $channel";
        if ($gdevEntry->{type} == &GCAN || $gdevEntry->{type} == &GSCI ||
                $gdevEntry->{type} == &GVISTNBUS) {
            $gryphon->cmdSend (gcDest => &SD_CARD, gcDestChan => $channel,
                    cmd => &CMD_INIT, data => [0]);
        }

    }
    $ioctlEntry->{currentspeed} = $newSpeed;
}

sub commify {
    local $_  = shift;
    1 while s/^([-+]?\d+)(\d{3})/$1,$2/;
    return $_;
}

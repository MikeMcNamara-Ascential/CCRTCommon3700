package Gryphon;

# Copyright 2000 Dearborn Group, Inc.  All rights reserved.
# $Id: Gryphon.pm,v 1.1 2007/02/23 15:15:58 chang Exp $
# POD documentation is located at the end of this file.

#require "gmsg.ph";

use Carp;
#use Data::Dumper;

$FRAME_HEADER = 'C4nC2';
$COMMAND_HEADER = 'C2n';
$DATA_HEADER = 'C2nC4NC2n';
$EVENT_HEADER = 'C2nN';
$SERVER_REG = 'a16a32';
$RETURN_CODE = 'N';
$SERVER_REG_RESP = 'C2n';
$FILTER_BODY = 'n2C2nH*H*';
$SCHED_BODY = "N3nC2$DATA_HEADER";

%Message = ();

require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw($FRAME_HEADER $COMMAND_HEADER $DATA_HEADER $EVENT_HEADER $FILTER_BODY %Message);

sub new {
    my $class = shift;
    my %args = (addr => '127.0.0.1', port => 7000, gcSrc => (&main::SD_CLIENT),
    	    timeout => 0.5, @_);
    my ($data, $user, $password, $rtn_code, $priv, $header, $reply, $addr);
    my ($sockfh, $sin, $id, $gryphon, $selectBit);
    my $AF_INET = 2; 
    my $SOCK_STREAM = 1;

    #
    # Establish a TCP/IP connection to the server
    #
    $sockfh = Symbol();
    unless (socket( $sockfh, $AF_INET, $SOCK_STREAM, 0)) {
	$@ = "Could not create socket: $!\n";
	close $sockfh;
	return undef;
    }
    $selectBit = '';
    vec ($selectBit, fileno ($sockfh), 1) = 1;

    if ($args{'non-block'}) {
        require Errno;
        require Socket;
        require Fcntl;

        my ($temp_bits, $flags);

        # Set the socket non-blocking
        $flags = 0;
        fcntl $sockfh, &F_GETFL, $flags;
        fcntl $sockfh, &F_SETFL, $flags | &O_NONBLOCK;

        if ($args{addr} =~ /^[0-9.]+$/) {
	    $addr = 0;
	    foreach (split '\.', $args{addr}) {
	        $addr = $addr * 256 + $_;
	    }
	    $reply = connect( $sockfh, pack( 'C2nN3', $AF_INET, 0, $args{port},
                    $addr )) ? 0 : -1;
        } else {
	    require Socket;
	    Socket->import (qw(sockaddr_in inet_aton));

	    $sin = sockaddr_in ($args{port}, inet_aton($args{addr}));
	    $reply = connect($sockfh, $sin) ? 0 : -1;
        }


        if ($reply < 1) {
            if ($! != &Errno::EINPROGRESS) {
                $@ = "Unable to connect to Gryphon at $args{addr}: $!";
                close $sockfh;
                return undef;
            }

            unless (select undef, $temp_bits = $selectBit, undef, $args{timeout}) {
                $! = &Errno::ETIMEDOUT;
                $@ = "Unable to connect to Gryphon at $args{addr}: $!";
                close $sockfh;
                return undef;
            }
            $reply = getsockopt ($sockfh, &Socket::SOL_SOCKET, &Socket::SO_ERROR);
            $reply = unpack 'L', $reply;
            if ($reply) {
                $! = $reply;
                $@ = "Unable to connect to Gryphon at $args{addr}: $!";
                close $sockfh;
                return undef;
            }
        }
        fcntl $sockfh, &F_SETFL, $flags;
    } else {
        if ($args{addr} =~ /^[0-9.]+$/) {
	    $addr = 0;
	    foreach (split '\.', $args{addr}) {
	        $addr = $addr * 256 + $_;
	    }
	    unless (connect( $sockfh,
	    	    pack( 'C2nN3', $AF_INET, 0, $args{port}, $addr ))) {
	        $@ = "Unable to connect to Gryphon at $args{addr}: $!";
	        close $sockfh;
	        return undef;
	    }
        } else {
	    require Socket;
	    Socket->import (qw(sockaddr_in inet_aton));

	    $sin = sockaddr_in ($args{port}, inet_aton($args{addr}));
	    unless (connect($sockfh, $sin)) {
	        $@ = "Unable to connect to Gryphon at $args{addr}: $!";
	        close $sockfh;
	        return undef;
	    }
        }
    }
    #
    # Register with the Gryphon server
    #
    ($user, $password) = ('', '');
    $data = pack ($COMMAND_HEADER, &main::CMD_SERVER_REG, 0, 0);
    $data .= pack ($SERVER_REG, $user, $password);
    $header = pack ($FRAME_HEADER, $args{gcSrc}, 0, &main::SD_SERVER, 0,
	    length $data, &main::FT_CMD,0);
    return undef unless send $sockfh, "$header$data", 0;
    $reply = readgryph ($sockfh, &main::FT_RESP, $selectBit, $args{timeout});
    ($rtn_code, $id, $priv) = 
    	    (unpack "$FRAME_HEADER$COMMAND_HEADER$RETURN_CODE$SERVER_REG_RESP", 
    	    $reply)[10, 11, 12];
    if ($rtn_code) {
    	$@ = "Unable to register with the server.  Got $rtn_code for a return code.\n";
	close $sockfh;
	return undef;
    }
    $gryphon->{Sockfh} = $sockfh;
    $gryphon->{'select'} = $selectBit;
    $gryphon->{cmd_defaults} = {gcDest => (&main::SD_CARD), gcDestChan => 1,
    	    	gcSrc => (&main::SD_CLIENT), gcSrcChan => $id, data => '',
		dataRecipe => 'C*', timeout => 1.5, flush => 0};
    $gryphon->{data_defaults} = {gcDest => (&main::SD_CARD), gcDestChan => 1,
    	    	gcSrc => (&main::SD_CLIENT), gcSrcChan => $id, data => '',
		hdr => '', extra => '', mode => 0, priority => 0, status => 0,
                timestamp => undef, context => 0, hdrBits => undef,
                hdrRecipe => 'C*', dataRecipe => 'C*', extraRecipe => 'C*',
                flush => 0};
    $gryphon->{misc_defaults} = {gcDest => (&main::SD_CARD), gcDestChan => 1,
    	    	gcSrc => (&main::SD_CLIENT), gcSrcChan => $id, data => '',
		flush => 0};
    $gryphon->{event_defaults} = {gcDest => (&main::SD_SERVER), gcDestChan => 1,
    	    	gcSrc => (&main::SD_CLIENT), gcSrcChan => $id, data => '',
		eventId => '', eventContext => 0, timestamp => undef,
		dataRecipe => 'C*', flush => 0};
    $gryphon->{receive_defaults} = {gcType => undef, timeout => .5 };
    $gryphon->{resp_elements} = $gryphon->{filt_elements} =
    	    $gryphon->{elements} = 0;
    $gryphon->{resp_data} = $gryphon->{filt_data} =
    	    $gryphon->{data} = '';
    $gryphon->{clientID} = $id;
    $gryphon->{returnString} = ['Ok', 'Unknown error', 'Unknown command',
    	    'Unsupported command', 'Invalid channel specified',
	    'Invalid destination', 'Invalid parameters',
	    'Invalid message', 'Invalid length field','Transmit failed',
    	    'Receive failed', 'Authorization failed',
	    'Memory allocation error', 'Command timed out', 'Unavailable',
	    'Buffer full', 'No such job', 'Not enough room on the disk'];

    return bless $gryphon, $class;
}

sub DESTROY {
    my $self = shift;
    close $self->{Sockfh};
}

{
my %special = ((&main::CMD_MSGRESP_ADD) => 'C3n',
    	       (&main::CMD_SCHED_TX) => 'N2');
sub cmdSend {
    my $self = shift;
    my %args = (%{$self->{cmd_defaults}}, @_);
    my $lex_data;

    if ($args{gcDest} == &main::SD_RESP &&
            $args{cmd} == &main::CMD_MSGRESP_ADD) {
        %args = (%args, (dataRecipe, 'C3n'));
        $args{data}[3] *= 100 unless ($args{data}[2] & &main::FR_PERIOD_MSGS);
    } elsif ($args{gcDest} == &main::SD_SCHED &&
            $args{cmd} == &main::CMD_SCHED_TX) {
        %args = (%args, (dataRecipe, 'N2'));
    }

    if ((ref $args{data}) =~ /^ARRAY$/) {
    	$args{data} = pack $args{dataRecipe}, @{$args{data}};
    } elsif ((ref $args{data}) =~ /^SCALAR$/) {
    	$args{data} = pack $args{dataRecipe}, ${$args{data}};
    } elsif ((ref $args{data}) =~ /^CODE$/) {
    	$args{data} = pack $args{dataRecipe}, &{$args{data}};
    } elsif ($args{data} =~ /^[0-9a-fA-F]+$/) {
    	$args{data} = pack 'H*', $args{data};
    }
    if ($args{cmd} == &main::CMD_CARD_ADD_FILTER) {
    	$lex_data = $args{data} . (pack 'CnN', $self->{filt_elements}, 0, 0) .
	    	$self->{filt_data};
	$self->{filt_data} = '';
	$self->{filt_elements} = 0;
    } elsif ($args{gcDest} eq &main::SD_RESP and $args{cmd} == &main::CMD_MSGRESP_ADD) {
    	$lex_data = substr $args{data}, 0, 1;
	$args{data} = substr $args{data}, 1;
	$lex_data .= pack 'C2', $self->{filt_elements}, $self->{resp_elements};
	$lex_data .= substr $args{data}, 0, 2;
	$lex_data .= pack 'C', 0;
	$lex_data .= (substr $args{data}, 2) . $self->{filt_data} .
	    	$self->{resp_data};
	$self->{filt_data} = $self->{resp_data} = '';
	$self->{filt_elements} = $self->{resp_elements} = 0;
    } elsif ($args{cmd} == &main::CMD_SCHED_TX) {
    	$lex_data = $args{data} . $self->{sched_data};
	$self->{sched_data} = '';
    } elsif ($args{cmd} == &main::CMD_CARD_TX) {
        local ($hdr, $data, $extra);
        my ($hdrBits, $msg);
        my $ts = $args{timestamp} ? $args{timestamp} : 0;
        %args = (%{$self->{cmd_defaults}}, %{$self->{data_defaults}}, @_);

        {
        no strict 'refs';
        foreach (qw/hdr data extra/) {
	    if (not defined $args{$_}) {
	        $$_ = '';
	    } elsif ((ref $args{$_}) =~ /^ARRAY$/) {
	        $$_ = pack $args{$_ . 'Recipe'}, @{$args{$_}};
	    } elsif ((ref $args{$_}) =~ /^SCALAR$/) {
	        if (not defined ${$args{$_}}) {
	    	    $$_ = '';
	        } else {
		    $$_ = pack $args{$_ . 'Recipe'}, ${$args{$_}};
	        }
	    } elsif ((ref $args{$_}) =~ /^CODE$/) {
	        $$_ = pack $args{$_ . 'Recipe'}, &{$args{$_}};
	    } elsif ($args{$_} =~ /^[0-9a-fA-F]+$/) {
    	        $$_ = pack 'H*', $args{$_};
	    } else {
	        $$_ = $args{$_};
	    }
        }
        }


        $hdrBits = $args{hdrBits} ? $args{hdrBits} : length ($hdr) * 8;
        $msg = $hdr . $data . $extra;

        $lex_data = (pack $DATA_HEADER,
    	        length $hdr, $hdrBits, length $data, length $extra,
                $args{mode} | &main::MODE_TX, $args{priority}, $args{status},
                $ts, 0, 0, 0) . $msg;
    } else {
    	$lex_data = $args{data};
    }
    $command = pack ($FRAME_HEADER . $COMMAND_HEADER,
    	    $args{gcSrc}, $args{gcSrcChan}, $args{gcDest}, $args{gcDestChan},
	    length ($lex_data)+4, (&main::FT_CMD), 0, $args{cmd}, 0, 0) . 
	    $lex_data;
    $command .= "\x00" x (3 - ((length ($command) + 3) % 4));
    flushgryph ($self->{Sockfh}, $self->{'select'}) if $args{flush};
    return undef unless send $self->{Sockfh}, $command, 0;
    $command = readgryph ($self->{Sockfh}, &main::FT_RESP, $self->{'select'},
    	    $args{timeout});
    return undef unless $command;
    if (wantarray) {
        $rtn_code = (unpack "$FRAME_HEADER$COMMAND_HEADER$RETURN_CODE", $command)[10];
        return ($rtn_code, (substr $command, 16));
    } else {
        return 1;
    }
}
}

sub cmdDefault {
    my $self = shift;
    $self->{cmd_defaults} = {%{$self->{cmd_defaults}}, @_};
}

sub dataSend {
    my $self = shift;
    my %args = (%{$self->{data_defaults}}, @_);
    local ($hdr, $data, $extra);
    my ($hdrBits, $msg);
    my $ts = $args{timestamp} ? $args{timestamp} : 0;

    {
    no strict 'refs';
    foreach (qw/hdr data extra/) {
	if (not defined $args{$_}) {
	    $$_ = '';
	} elsif ((ref $args{$_}) =~ /^ARRAY$/) {
	    $$_ = pack $args{$_ . 'Recipe'}, @{$args{$_}};
	} elsif ((ref $args{$_}) =~ /^SCALAR$/) {
	    if (not defined ${$args{$_}}) {
	    	$$_ = '';
	    } else {
		$$_ = pack $args{$_ . 'Recipe'}, ${$args{$_}};
	    }
	} elsif ((ref $args{$_}) =~ /^CODE$/) {
	    $$_ = pack $args{$_ . 'Recipe'}, &{$args{$_}};
	} elsif ($args{$_} =~ /^[0-9a-fA-F]+$/) {
    	    $$_ = pack 'H*', $args{$_};
	} else {
	    $$_ = $args{$_};
	}
    }
    }


    $hdrBits = $args{hdrBits} ? $args{hdrBits} : length ($hdr) * 8;
    $msg = $hdr . $data . $extra;

    $command = (pack $FRAME_HEADER . $DATA_HEADER,
    	    $args{gcSrc}, $args{gcSrcChan}, $args{gcDest}, $args{gcDestChan},
	    length ($msg)+16, (&main::FT_DATA), 0, length $hdr,
	    $hdrBits, length $data, length $extra, $args{mode} | &main::MODE_TX,
	    $args{priority}, $args{status}, $ts, 0, 0, 0) . $msg;
    $command .= "\x00" x (3 - ((length ($command) + 3) % 4));
    flushgryph ($self->{Sockfh}, $self->{'select'}) if $args{flush};
    send $self->{Sockfh}, $command, 0;
}

sub dataDefault {
    my $self = shift;
    $self->{data_defaults} = {%{$self->{data_defaults}}, @_};
}

sub miscSend {
    my $self = shift;
    my %args = (%{$self->{misc_defaults}}, @_);

    $command = pack ($FRAME_HEADER,
    	    $args{gcSrc}, $args{gcSrcChan}, $args{gcDest}, $args{gcDestChan},
	    length ($args{data}), (&main::FT_MISC), 0) . $args{data};
    $command .= "\x00" x (3 - ((length ($command) + 3) % 4));
    flushgryph ($self->{Sockfh}, $self->{'select'}) if $args{flush};
    send $self->{Sockfh}, $command, 0;
}

sub miscDefault {
    my $self = shift;
    $self->{misc_defaults} = {%{$self->{misc_defaults}}, @_};
}


sub eventSend {
    my $self = shift;
    my %args = (%{$self->{event_defaults}}, @_);
    my $ts = $args{timestamp} ? $args{timestamp} : 0;

    if ((ref $args{data}) =~ /^ARRAY$/) {
    	$args{data} = pack $args{dataRecipe}, (@{$args{data}});
    } elsif ((ref $args{data}) =~ /^SCALAR$/) {
    	$args{data} = pack $args{dataRecipe}, ${$args{data}};
    } elsif ((ref $args{data}) =~ /^CODE$/) {
    	$args{data} = pack $args{dataRecipe}, &{$args{data}};
    } elsif ($args{data} =~ /^[0-9a-fA-F]+$/) {
    	$args{data} = pack 'H*', $args{data};
    }

    $command = (pack $FRAME_HEADER . $EVENT_HEADER,
    	    $args{gcSrc}, $args{gcSrcChan}, $args{gcDest}, $args{gcDestChan},
	    length ($args{data})+8, (&main::FT_EVENT), 0, $args{eventId},
	    $args{eventContext}, 0, $ts) . $args{data};
    $command .= "\x00" x (3 - ((length ($command) + 3) % 4));
    flushgryph ($self->{Sockfh}, $self->{'select'}) if $args{flush};
    send $self->{Sockfh}, $command, 0;
}

sub eventDefault {
    my $self = shift;
    $self->{event_defaults} = {%{$self->{event_defaults}}, @_};
}

sub filterBlock {
    my $self = shift;
    my %args = ('offset', 0, 'type', &main::FILTER_DATA_TYPE_DATA, @_);
    my $temp;

    #$args{type} = $filter_type_xlate{$args{type}};
    if (exists $args{mask}) {
    	$temp = pack $FILTER_BODY, $args{offset}, length ($args{mask})/2,
	    	$args{type}, (&main::BIT_FIELD_CHECK), 0, $args{pattern},
		$args{mask};
    } else {
    	$temp = pack $FILTER_BODY, $args{offset}, length ($args{pattern})/2,
	    	$args{type}, $args{operator}, 0, $args{pattern},
                '0' x length $args{pattern};
    }
    $temp .= "\x00" x (3 - ((length ($temp) + 3) % 4));
    $self->{filt_data} .= $temp;
    $self->{filt_elements}++;

}

sub responseBlock {
    my $self = shift;
    my %temp = @_;
    my (%args, @args, $flag);
    local ($hdr, $data, $extra);
    
    @args = (qw/data/);
    if (exists $temp{cmd}) {
    	%args = (%{$self->{cmd_defaults}}, %temp);
    } elsif (exists $temp{event}) {
    	%args = (%{$self->{event_defaults}}, %temp);
    } elsif (exists $temp{misc}) {
    	%args = (%{$self->{misc_defaults}}, %temp);
    } else  {
    	%args = (%{$self->{data_defaults}}, %temp);
	@args = (qw/hdr data extra/);
    }
    
    {
    no strict 'refs';
    foreach (@args) {
	if (not defined $args{$_}) {
	    $$_ = '';
	} elsif ((ref $args{$_}) =~ /^ARRAY$/) {
	    $$_ = pack $args{$_ . 'Recipe'}, @{$args{$_}};
	} elsif ((ref $args{$_}) =~ /^SCALAR$/) {
	    if (not defined ${$args{$_}}) {
	    	$$_ = '';
	    } elsif (not defined $args{$_ . 'Recipe'}) {
	    	$$_ = ${$args{$_}};
	    } else {
	    	$$_ = pack $args{$_ . 'Recipe'}, ${$args{$_}};
	    }
	} elsif ((ref $args{$_}) =~ /^CODE$/) {
	    $$_ = pack $args{$_ . 'Recipe'}, &{$args{$_}};
	} elsif ($args{$_} =~ /^[0-9a-fA-F]+$/) {
    	    $$_ = pack 'H*', $args{$_};
	} else {
	    $$_ = $args{$_};
	}
    }
    }
    
    $flag = $args{flag} ? $args{flag} : 0;
    if (exists $temp{cmd}) {
	if ($args{cmd} == &main::CMD_CARD_ADD_FILTER) {
    	    $data .= (pack 'CnN', $self->{filt_elements}, 0, 0) .
	    	    $self->{filt_data};
	    $self->{filt_data} = '';
	    $self->{filt_elements} = 0;
	} elsif ($args{gcDest} eq &main::SD_RESP and $args{cmd} == &main::CMD_MSGRESP_ADD) {
    	    $data .= (pack 'CnN', $self->{filt_elements}, 0, 0) .
	    	    $self->{resp_data};
	    $self->{resp_data} = '';
	    $self->{resp_elements} = 0;
	} elsif ($args{cmd} == &main::CMD_SCHED_TX) {
    	    $data .= $self->{sched_data};
	    $self->{sched_data} = '';
	}
	$self->{resp_data} .= pack ($FRAME_HEADER . $COMMAND_HEADER,
    		$args{gcSrc}, $args{gcSrcChan}, $args{gcDest}, $args{gcDestChan},
		length ($data)+4, (&main::FT_CMD) | $flag, 0,
		$args{cmd}, 0, 0) .  $data;
    } elsif (exists $temp{event}) {
    	my $ts = $args{timestamp} ? $args{timestamp} : 0;
	$self->{resp_data} .= (pack $FRAME_HEADER . $EVENT_HEADER,
    		$args{gcSrc}, $args{gcSrcChan}, $args{gcDest}, $args{gcDestChan},
		length ($data)+8, (&main::FT_EVENT) | $flag, 0, $args{event},
		$args{eventContext}, 0, $ts) . $data;
    } elsif (exists $temp{misc}) {
    	$self->{resp_data} .= (pack $FRAME_HEADER,  
    		$args{gcSrc}, $args{gcSrcChan}, $args{gcDest}, $args{gcDestChan},
		length ($temp{misc}), (&main::FT_MISC) | $flag, 0) . $temp{misc};
    } else {
    	my ($hdrBits, $msg);
    	my $ts = $args{timestamp} ? $args{timestamp} : 0;
	
	$hdrBits = $args{hdrBits} ? $args{hdrBits} : length ($hdr) * 8;
	$msg = $hdr . $data . $extra;
    	$self->{resp_data} .= (pack $FRAME_HEADER . $DATA_HEADER,
    		$args{gcSrc}, $args{gcSrcChan}, $args{gcDest}, $args{gcDestChan},
		length ($msg)+16, (&main::FT_DATA) | $flag, 0, length $hdr,
		$hdrBits, length $data, length $extra,
                $args{mode} | &main::MODE_TX, $args{priority}, $args{status},
                $ts, 0, 0, 0) . $msg;
    }
    $self->{resp_data} .= "\x00" x (3 - ((length ($self->{resp_data}) + 3) % 4));
    $self->{resp_elements}++;
}

sub schedulerBlock {
    my $self = shift;
    my %args = ('sleep', 0, 'count', 1, 'period', 0, 'chan', 0, 'flags', 0,
    	    %{$self->{data_defaults}}, @_);
    local ($hdr, $data, $extra);
    my ($hdrBits, $msg);
    my $temp;

    {
    no strict 'refs';
    foreach (qw/hdr data extra/) {
	if (not defined $args{$_}) {
	    $$_ = '';
	} elsif ((ref $args{$_}) =~ /^ARRAY$/) {
	    $$_ = pack $args{$_ . 'Recipe'}, @{$args{$_}};
	} elsif ((ref $args{$_}) =~ /^SCALAR$/) {
	    if (not defined ${$args{$_}}) {
	    	$$_ = '';
	    } else {
	    	$$_ = pack $args{$_ . 'Recipe'}, ${$args{$_}};
	    }
	} elsif ((ref $args{$_}) =~ /^CODE$/) {
	    $$_ = pack $args{$_ . 'Recipe'}, &{$args{$_}};
	} elsif ($args{$_} =~ /^[0-9a-fA-F]+$/) {
    	    $$_ = pack 'H*', $args{$_};
	} else {
	    $$_ = $args{$_};
	}
    }
    }

    $hdrBits = $args{hdrBits} ? $args{hdrBits} : length ($hdr) * 8;
    $msg = $hdr . $data . $extra;

    $temp = (pack $SCHED_BODY, $args{'sleep'}*1000, $args{count},
            $args{period}*1000, $args{flags}, $args{chan}, 0, length $hdr,
            $hdrBits, length $data, length $extra, $args{mode} | &main::MODE_TX,
            $args{priority}, $args{status}, 0, 0, 0, 0) . $msg;
    $temp .= "\x00" x (3 - ((length ($temp) + 3) % 4));
    $self->{sched_data} .= $temp;
    $self->{elements}++;
    	
}

sub recvDefault {
    my $self = shift;
    $self->{receive_defaults} = {%{$self->{receive_defaults}}, @_};
}
sub recv {
    my $self = shift;
    my %args = (%{$self->{receive_defaults}}, @_);
    my ($msg, $header, %typeDef);

    if (defined $args{gcType}) {
	$msg = readgryph ($self->{Sockfh}, $args{gcType}, $self->{'select'},
    		$args{timeout});
    } else {
	$msg = (readgryph ($self->{Sockfh}, undef, $self->{'select'},
    		$args{timeout}))[1];
    }

    %Message = ();
    if ($msg) {
	@temp = unpack $FRAME_HEADER, $msg;
	foreach (qw/gcSrc gcSrcChan gcDest gcDestChan gcLength gcType/) {
	    $Message{$_} = shift @temp;
	}
	$msg = substr $msg, 8;
	$msg = substr $msg, 0, $Message{gcLength};
	if ($Message{gcType} == &main::FT_MISC) {
	    %typeDef = (%{$self->{misc_defaults}}, %args);
	    $Message{dataRaw} = $msg;
	    $Message{dataCooked} = [unpack $typeDef{dataRecipe}, $msg]
	    	    if $typeDef{dataRecipe};
	} elsif ($Message{gcType} == &main::FT_DATA) {
	    %typeDef = (%{$self->{data_defaults}}, %args);
	    @temp = unpack $DATA_HEADER, $msg;
	    foreach (qw/hdrLen hdrBits dataLen extraLen mode priority
	    	    status timestamp context/) {
		$Message{$_} = shift @temp;
	    }
	    $msg = substr $msg, 16;
	    $Message{hdrRaw} = substr $msg, 0 ,$Message{hdrLen};
	    $msg = substr $msg, $Message{hdrLen};
	    $Message{dataRaw} = substr $msg, 0, $Message{dataLen};
	    $msg = substr $msg, $Message{dataLen};
	    $Message{extraRaw} = substr $msg, 0, $Message{extraLen};
	    $Message{hdrCooked} = [unpack $typeDef{hdrRecipe}, $Message{hdrRaw}]
	    	    if $typeDef{hdrRecipe};
	    $Message{dataCooked} = [unpack $typeDef{dataRecipe}, $Message{dataRaw}]
	    	    if $typeDef{dataRecipe};
	    $Message{extraCooked} = [unpack $typeDef{extraRecipe}, $Message{extraRaw}]
	    	    if $typeDef{extraRecipe};
	} elsif ($Message{gcType} == &main::FT_EVENT) {
	    @temp = unpack $EVENT_HEADER, $msg;
	    foreach (qw/eventId eventContext reserved timestamp/) {
		$Message{$_} = shift @temp;
	    }
	    $msg = substr $msg, 8;
	    $Message{dataRaw} = $msg;
	    %typeDef = (%{$self->{event_defaults}}, %args);
	    $Message{dataCooked} = [unpack $typeDef{dataRecipe}, $msg]
	    	    if $typeDef{dataRecipe};
	}
	return 1;
    } else {
    	return undef;
    }
}

#
# This subroutine was lifted from Symbol.pm to provide an extremely
# lightweight method of generating anonymous filehandles.
#
my $genseq = 0;
sub Symbol {
    my $genpkg = 'Gryphon::';
    my $name = "GEN" . $genseq++;
    my $ref = \*{$genpkg . $name};
    delete $$genpkg{$name};
    $ref;
}

{
my @stash = ();
sub readgryph {
    my ($socket, $desired_type, $selectBits, $timeout) = @_;
    my ($msg, $length, $padding, $type, $tmp, $temp_bits, @scratch);
    
    if (@stash) {
	@scratch = @stash;
	@stash = ();
	while (@scratch) {
    	    $type = shift @scratch;
	    $msg = shift @scratch;
	    if (not defined $desired_type) {
		push @stash, @scratch;
    		return ($type, $msg);
	    } elsif ($type == $desired_type) {
		push @stash, @scratch;
    		return $msg;
	    }
	    push @stash, ($type, $msg);
	}
    }
	
  waiting:
    if (scalar select ($temp_bits = $selectBits, undef, undef, $timeout)) {
    	$msg = '';
	$length = 8;
	while ($length) {
	    unless( defined( CORE::recv $socket, $tmp, $length, 0)) {
		croak "recv error: $!";
	    }
	    $length -= length $tmp;
	    $msg .= $tmp;
	}
	($length, $type) = (unpack $FRAME_HEADER, $msg)[4, 5];
	$padding = 3 - (($length + 3) % 4);
	$length += $padding;
	while ($length) {
	    unless( defined( CORE::recv $socket, $tmp, $length, 0)) {
		croak "recv error: $!";
	    }
	    $length -= length $tmp;
	    $msg .= $tmp;
	}
	$msg = substr $msg, 0, -$padding if $padding;
	if (not defined $desired_type) {
    	    return ($type, $msg);
	} elsif ($type == $desired_type) {
    	    return $msg;
	}
    	push @stash, ($type, $msg);
	goto waiting;
    } else {
    	return undef;
    }
}

sub flushgryph {
    my ($socket, $selectBits) = @_;
    my $length;
    my ($type, $tmp, $temp_bits, $msg);

    @stash = ();
    for (;;) {
    	$length = 8;
	$msg = '';
	if (select ($temp_bits = $selectBits, undef, undef, 0)) {
	    while ($length) {
		unless( defined( CORE::recv $socket, $tmp, $length, 0)) {
		    croak "recv error: $!";
		}
		$length -= length $tmp;
	    	$msg .= $tmp;
	    }
	    ($length) = (unpack $FRAME_HEADER, $msg)[4];
	    $length += 3 - (($length + 3) % 4);
	    while ($length) {
		unless( defined( CORE::recv $socket, $tmp, $length, 0)) {
		    croak "recv error: $!";
		}
		$length -= length $tmp;
	    }
	} else {
    	    return;
	}
    }
}
}
1;


__END__

=head1 NAME

Gryphon - Gryphon Communication Protocol complexities hidden behind a clean
object-oriented interface.

=head1 SYNOPSIS

 # open a connection to the Gryphon, register with the Gryphon server
 # program, and ...

 BEGIN {
 #
 # Requiring the gmsg.ph file allows the use of symbolic names for the
 # values defined in gmsg.h  A subroutine is created for each defined
 # value which returns the value or string original gmsg.h file.  To
 # use the values, prepend them with an apersand (ie. &SD_CLIENT and 
 # &FT_DATA).
 #
 require "gmsg.ph";
 }
 use Gryphon;

 $gryphon = new Gryphon addr => $ip_address;
 $gryphon2 = Gryphon->new (addr => $ip_address);
 
 die "$@\n" unless $gryphon;
 die "$@\n" unless $gryphon2;

 $gryphon->miscDefault ( gcDest => $SD_CUSTOM );
 $gryphon->recvDefault ( gcType => &FT_MISC, timeout => 0 );
 $gryphon->miscSend ( data => $message );

 unless( $gryphon->recv ) {
	 $recvTimer = $MainWin->after ( $POLL_PERIOD, \&receive );
	 return;
 }

 $gryphon->miscDefault( gcDestChan => $Message{gcSrcChan} );

 if( $Message{dataRaw} =~ /pattern/ ) {
 }

 die "No response\n" unless $gryphon2->recv;

 # close the Gryphon and TCP/IP sessions:
 undef $gryphon;
 $gryphon2 = undef;

=head1 DESCRIPTION

=head2 Functions

=over 4

=item Gryphon->new()

=over 4

=item Arguments and default values:

 addr => '127.0.0.1'
 port => 7000
 gcSrc => SD_CLIENT
 timeout => 0.5

=item Return values:

If it succeeds, a reference to a Gryphon object is returned.  The returned
reference is used with all other methods to indicate which connection to use.

If it fails, I<undef> is returned.  An error message, suitable for printing, is
present in I<$@>;

=item Description:

Attempts to establish a TCP/IP connection to the Gryphon server listening at 
port I<port> at IP address I<addr>, then register with the server as a Gryphon 
source type I<gcSrc>.  If no response is received from the Gryphon Register
command within the timeout period, a failure is declared.

=back

=item cmdDefault()

=over 4

=item Arguments and default values:

gcDest => SD_CARD
gcDestChan => 1
gcSrc => SD_CLIENT
gcSrcChan => nn (assigned by the server at time of registration)
dataRecipe => 'C*'
data => ''
	data may be specified by either a string of hex characters
	(ASCII hex), a packed scalar, or a reference to an array,
	scalar or subroutine.  If it is a reference, the data in the
	referent will be packed by the library according to dataRecipe.
timeout => 0  The amount of time in seconds and 
flush => 0
	If set to true, all buffered incoming TCP traffic will be flushed before
	the send is done.

=item Return values: None.

=item Description:

	The argument values supplied become the new default values used in 
subsequent calls to I<cmdSend()>.

=back

=item cmdSend ()

Arguments and default values:

	See I<cmdDefault>.

Return values:

If success, returns a list of two items: the "Return code" and "Response data" 
from the FT_RESP frame.
If failure, returns I<undef>;

Description:

	Sends the Gryphon command (gc frame type = FT_CMD) specified in I<data>. 
Any of the arguments listed in I<cmdDefault()> can be supplied; the supplied 
values override the default values only for the duration of the current call.


=item dataDefault

Arguments and default values:

	gcDest => SD_CARD
	gcDestChan => 1
	gcSrc => SD_CLIENT
	gcSrcChan => <assigned by the server at time of registration>
	priority => 0
	timestamp => undef
	context => 0
	hdrBits => undef
	hdrRecipe => 'C*'
	dataRecipe => 'C*'
	extraRecipe => 'C*'
	hdr => ''
	extra => ''
	data => ''
		I<hdr>, I<extra> and I<data> can be specified by either a string 
		of hex characters, a packed scalar, or a reference to an array, 
		scalar or subroutine.  If it is a reference, the data in the 
		referent will be packed by the library according to the 
		corresponding Recipe.
	flush => 0
		If set to true, all buffered incoming TCP traffic will be flushed before
		the send is done.

Return values:

	A reference to the hash containing the defaults.


Description:

	The argument values supplied become the new default values used in 
subsequent calls to I<dataSend()>.


=item dataSend

Arguments and default values:

	See I<dataDefault>.

Return values:

If success, returns the number of bytes sent to the Gryphon.
If failure, returns I<undef> and an error code is put into I<$!>.

Description:

	Sends the Gryphon network data frame (gc frame type = FT_DATA) specified 
in I<hdr>, I<extra>, I<data>, etc.  Any of the arguments listed in 
I<dataDefault()> can be supplied; the supplied values override the 
default values only for the duration of the current call.


=item miscDefault

Arguments and default values:

	gcDest => SD_CARD
	gcDestChan => 1
	gcSrc => SD_CLIENT
	gcSrcChan => <assigned by the server at time of registration>
	data => ''
	flush => 0
		If set to true, all buffered incoming TCP traffic will be flushed before
		the send is done.

Return values:

	A reference to the hash containing the defaults.

Description:

	The argument values supplied become the new default values used in 
subsequent calls to I<miscSend()>.


=item miscSend

Arguments and default values:

	See I<miscDefault>.

Return values:

If success, returns the number of bytes sent to the Gryphon.
If failure, returns I<undef> and an error code is put into I<$!>.

Description:

	Sends the Gryphon miscellaneous frame (gc frame type = FT_MISC) specified 
in I<data>.  Any of the arguments listed in I<miscDefault()> can be supplied; 
the supplied values override the default values only for the duration of 
the current call.


=item filterBlock

=item schedulerBlock

=item recv

=item recvDefault

Override any of the following, which will be used in .... (unless also
overridden in those calls...?):

	gcType => undef
	timeout => .5 

=back

=head2 Exported Default Symbols

=over 4
=item %Message
=item $FRAME_HEADER
=item $COMMAND_HEADER
=item $DATA_HEADER 
=item $EVENT_HEADER 
=item $FILTER_BODY
=back

=head1 AUTHOR

Steve Limkemann

=cut

